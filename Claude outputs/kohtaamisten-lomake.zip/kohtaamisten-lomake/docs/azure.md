# Julkaisu Azureen

## Ympäristöt

Kehitys- ja tuotantoympäristöt ovat yhteisiä muiden säätiön sovellusten kanssa: kummassakin
ympäristössä on yksi PostgreSQL-palvelin, ja jokaisella sovelluksella on siellä oma tietokanta
ja oma käyttäjä. Sammio hakee tuotantodatan päivittäin omalla lukutunnuksellaan.

**Kehitys / demo** (vain testidataa)

| | |
|---|---|
| Resurssiryhmä | `rg-kehitys-sandbox` (Sweden Central) |
| Sovellus | Container App `kohtaamiset` ympäristössä `wry-env`, 0–1 replikaa (sammuu tauon ajaksi) |
| Osoite | https://kohtaamiset.happyisland-ae542e9e.swedencentral.azurecontainerapps.io |
| Tietokanta | `kohtaamiset` (käyttäjä `kohtaamiset`) palvelimella `psql-wry-dev` |
| Konttikuvat | `ca95be79f8d0acr.azurecr.io/kohtaamiset:<commit>` |

Palvelin `psql-wry-dev` on nimestään huolimatta yhteinen kehityspalvelin: sitä käyttävät wry ja
tämä sovellus. Palvelinta ei poisteta, palauteta eikä sen admin-salasanaa vaihdeta sopimatta
molempien sovellusten ylläpitäjien kanssa. Kehitysympäristöön ei viedä oikeaa asiakasdataa:
palvelimen palomuuri päästää läpi kaikki Azuren osoitteet.

Uusi versio demoon (ei vielä automaattista julkaisua):

```bash
SHA=$(git rev-parse --short HEAD)
az acr build -r ca95be79f8d0acr -t kohtaamiset:$SHA --build-arg GIT_COMMIT=$SHA .
az containerapp update -g rg-kehitys-sandbox -n kohtaamiset --image ca95be79f8d0acr.azurecr.io/kohtaamiset:$SHA
```

**Tuotanto**: pystytetään IT:n kanssa alla olevan ohjeen mukaan. Tuotantopalvelimelle neutraali
nimi (esim. `psql-shared-prod`), koska Azure-resursseja ei voi nimetä uudelleen.

## Tuotannon kohderakenne

Kohderakenne on valittu niin, että kuukausikulu pysyy pienenä ja sillä on katto:

| Osa | Valinta | Arvio €/kk |
|---|---|---|
| Sovellus | Azure Container Apps (Consumption), 0,25 vCPU / 0,5 GiB, 1 replika | 0–15 |
| Tietokanta | Oma tietokanta Sammion PostgreSQL 16 -palvelimella | ~0 |
| – tai | Oma Flexible Server, Burstable B1ms, 32 GB | 15–20 |
| Konttikuvat | GitHub Container Registry | 0 |
| Lokit | Log Analytics, päiväkatto 0,1 GB | 0–2 |

Yhteensä noin 5–20 €/kk (Sammion palvelimella) tai 20–40 €/kk (oma kanta). Tarkista hinnat
[hintalaskurista](https://azure.microsoft.com/pricing/calculator/) ennen pystytystä.

Kulut pysyvät hallinnassa, koska
- replikoita on enintään yksi, joten sovellus ei skaalaudu kalliimmaksi kuormituksen mukana
- kaikki on samassa resurssiryhmässä, jolle asetetaan budjetti ja hälytykset
- käytössä ei ole Application Gatewayta, Front Dooria, korkeaa käytettävyyttä eikä private endpointeja.

Tarvitset Azure-tilauksen resurssiryhmän Contributor-oikeudet, `az`-komentorivin
(`az login`) ja `containerapp`-laajennuksen (`az extension add -n containerapp`).

## 1. Resurssiryhmä ja budjetti

```bash
RG=rg-kohtaamiset
LOC=swedencentral
az group create -n $RG -l $LOC
```

Budjetti: Azure-portaali → Cost Management → Budgets → Add. Rajaus resurssiryhmään,
esim. 40 €/kk, sähköpostihälytykset 50 %, 80 % ja 100 % kohdalla.

## 2. Lokit päiväkatolla

```bash
az monitor log-analytics workspace create -g $RG -n log-kohtaamiset -l $LOC
az monitor log-analytics workspace update -g $RG -n log-kohtaamiset --quota 0.1
LAW_ID=$(az monitor log-analytics workspace show -g $RG -n log-kohtaamiset --query customerId -o tsv)
LAW_KEY=$(az monitor log-analytics workspace get-shared-keys -g $RG -n log-kohtaamiset --query primarySharedKey -o tsv)
```

## 3. Verkko

Sovellus ja tietokanta samaan virtuaaliverkkoon, jolloin kantaan ei pääse internetistä.

```bash
az network vnet create -g $RG -n vnet-kohtaamiset --address-prefixes 10.20.0.0/16
az network vnet subnet create -g $RG --vnet-name vnet-kohtaamiset -n snet-apps \
  --address-prefixes 10.20.0.0/27 --delegations Microsoft.App/environments
az network vnet subnet create -g $RG --vnet-name vnet-kohtaamiset -n snet-db \
  --address-prefixes 10.20.1.0/28 --delegations Microsoft.DBforPostgreSQL/flexibleServers
```

Jos tietokanta tulee Sammion palvelimelle, Sammion ylläpito kertoo, mihin verkkoon sovellus
liitetään (esim. vertaisverkko Sammion verkkoon). Silloin `snet-db`-aliverkkoa ei tarvita.

## 4. Tietokanta

**Sammion palvelimella** (Sammion ylläpito ajaa):

```sql
CREATE ROLE kohtaamiset LOGIN PASSWORD '<vahva salasana>';
CREATE DATABASE kohtaamiset OWNER kohtaamiset;
```

**Tai oma palvelin:**

```bash
az postgres flexible-server create -g $RG -n psql-kohtaamiset -l $LOC \
  --version 16 --tier Burstable --sku-name Standard_B1ms --storage-size 32 \
  --backup-retention 7 --high-availability Disabled \
  --vnet vnet-kohtaamiset --subnet snet-db \
  --admin-user kohtaamiset --admin-password '<vahva salasana>' \
  --database-name kohtaamiset --yes
```

Sovellus luo taulut itse ensimmäisellä käynnistyksellä.

## 5. Container Apps -ympäristö

```bash
SUBNET_ID=$(az network vnet subnet show -g $RG --vnet-name vnet-kohtaamiset -n snet-apps --query id -o tsv)
az containerapp env create -g $RG -n cae-kohtaamiset -l $LOC \
  --enable-workload-profiles \
  --infrastructure-subnet-resource-id $SUBNET_ID \
  --logs-workspace-id $LAW_ID --logs-workspace-key $LAW_KEY
```

## 6. Sovellus

Kuvan on oltava rekisterissä ennen ensimmäistä luontia: aja GitHubissa Actions → Deploy →
Run workflow, tai rakenna ja vie kuva käsin. Container App hakee kuvan yksityisestä GHCR:stä
GitHub-tokenilla, jolla on vain `read:packages`-oikeus (mieluiten palvelutunnukselta, ei henkilöltä).

```bash
az containerapp create -g $RG -n kohtaamiset --environment cae-kohtaamiset \
  --image ghcr.io/a-klinikkasaatio/kohtaamisten-lomake:<commit-sha> \
  --registry-server ghcr.io --registry-username <github-tunnus> --registry-password <read:packages-token> \
  --ingress external --target-port 3000 \
  --cpu 0.25 --memory 0.5Gi --min-replicas 1 --max-replicas 1 \
  --secrets \
    database-url='postgres://kohtaamiset:<salasana>@<palvelin>.postgres.database.azure.com:5432/kohtaamiset' \
    session-secret="$(openssl rand -hex 32)" \
    pseudonym-key='<openssl rand -hex 32, talleta myös salasanaholviin>' \
    entra-client-secret='<…>' mailgun-api-key='<…>' \
  --env-vars \
    NODE_ENV=production DATABASE_SSL=require \
    DATABASE_URL=secretref:database-url SESSION_SECRET=secretref:session-secret PSEUDONYM_KEY=secretref:pseudonym-key \
    ENTRA_TENANT_ID=<…> ENTRA_CLIENT_ID=<…> ENTRA_CLIENT_SECRET=secretref:entra-client-secret \
    MAILGUN_DOMAIN=<…> MAILGUN_API_KEY=secretref:mailgun-api-key \
    ADMIN_EMAIL=<etunimi.sukunimi@a-klinikka.fi>
```

- Salasanan erikoismerkit `DATABASE_URL`:ssa on URL-koodattava.
- `PSEUDONYM_KEY`:tä ei saa vaihtaa eikä hukata: ilman sitä asiakaslinkitykset katkeavat.
  Säilytä kopio säätiön salasanaholvissa.
- Jos IT edellyttää Key Vaultia, salaisuudet voi viitata sieltä managed identityllä
  (`--secrets name=keyvaultref:<url>,identityref:system`).

Osoite ja `APP_URL`:

```bash
FQDN=$(az containerapp show -g $RG -n kohtaamiset --query properties.configuration.ingress.fqdn -o tsv)
az containerapp update -g $RG -n kohtaamiset --set-env-vars APP_URL=https://$FQDN
```

Health probe: portaali → Container App → Containers → Health probes → liveness ja readiness,
HTTP `GET /healthz` porttiin 3000.

Entra-sovellusrekisteröintiin lisätään paluuosoite `https://<FQDN>/auth/callback`.

Ensimmäisen adminin väliaikainen salasana tulostuu sovelluksen lokiin
(`az containerapp logs show -g $RG -n kohtaamiset --tail 50`). Vaihda se heti, tai anna adminille
Entrassa sovellusrooli `admin`, jolloin salasanaa ei tarvita.

## 7. Automaattinen julkaisu GitHubista

Workflow `.github/workflows/deploy.yml` julkaisee jokaisen main-haaraan tulevan muutoksen,
kun CI on mennyt läpi. Azureen kirjaudutaan federoidulla tunnuksella (OIDC), jolla on oikeus
vain tähän Container Appiin.

```bash
APP_ID=$(az ad app create --display-name github-kohtaamiset-deploy --query appId -o tsv)
az ad sp create --id $APP_ID
az ad app federated-credential create --id $APP_ID --parameters '{
  "name": "github-production",
  "issuer": "https://token.actions.githubusercontent.com",
  "subject": "repo:a-klinikkasaatio/kohtaamisten-lomake:environment:production",
  "audiences": ["api://AzureADTokenExchange"]
}'
az role assignment create --assignee $APP_ID --role Contributor \
  --scope $(az containerapp show -g $RG -n kohtaamiset --query id -o tsv)
```

GitHub → Settings → Secrets and variables → Actions → Variables:

| Nimi | Arvo |
|---|---|
| `AZURE_CLIENT_ID` | `$APP_ID` |
| `AZURE_TENANT_ID` | `az account show --query tenantId -o tsv` |
| `AZURE_SUBSCRIPTION_ID` | `az account show --query id -o tsv` |
| `AZURE_RESOURCE_GROUP` | `rg-kohtaamiset` |
| `AZURE_CONTAINER_APP` | `kohtaamiset` |

Lisää GitHubiin myös ympäristö `production` (Settings → Environments). Siihen voi asettaa
hyväksyjän, jolloin julkaisu odottaa hyväksyntää.

## Tarkistus

- `https://<FQDN>/healthz` palauttaa `{"ok":true}`.
- Kirjautuminen, kirjaus ja Excel-vienti toimivat.
- Cost Management → Budgets näyttää budjetin ja kertyneet kulut.
