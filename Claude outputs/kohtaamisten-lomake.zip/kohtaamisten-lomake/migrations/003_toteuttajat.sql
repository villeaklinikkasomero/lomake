-- Muut toteuttajat kuin sovelluksen käyttäjät (esim. vapaaehtoinen, vertainen). Ylläpidettävissä
-- kohdassa Hallinta → Toteuttajat. encounters.performer_type on joko 'kayttaja' tai tämän taulun key.
--   recorder_index = mikä kirjaajan rooli (RECORDER_ROLES, src/db.js) kirjaukseen tallentuu
CREATE TABLE performer_types (
  key            text PRIMARY KEY,
  label          text NOT NULL,
  recorder_index smallint NOT NULL DEFAULT 2 CHECK (recorder_index IN (0,1,2)),
  active         smallint NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
  sort           integer NOT NULL DEFAULT 0
);
-- Aiempi "Vapaaehtoinen tai vertainen" (performer_type = 'vapaaehtoinen') jaetaan kahdeksi
INSERT INTO performer_types (key, label, recorder_index, sort) VALUES
  ('vapaaehtoinen', 'Vapaaehtoinen', 2, 10),
  ('vertainen', 'Vertainen', 2, 20);
-- Toteuttajan tyyppi ei enää rajoitu kiinteisiin arvoihin (tarkistetaan sovelluksessa)
ALTER TABLE encounters DROP CONSTRAINT IF EXISTS encounters_performer_type_check;
