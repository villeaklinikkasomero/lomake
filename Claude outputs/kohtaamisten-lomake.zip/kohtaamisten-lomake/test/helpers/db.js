'use strict';
// Testikanta: jokainen testitiedosto saa oman tilapäisen tietokannan, joka poistetaan lopuksi.
// Vaatii käynnissä olevan PostgreSQLin (paikallisesti: docker compose up -d db).
// Kutsu ennen kuin src/db tai src/server ladataan, koska ne lukevat DATABASE_URL:n latautuessaan.

const crypto = require('crypto');
const { Client } = require('pg');

const BASE_URL = process.env.TEST_DATABASE_URL || process.env.DATABASE_URL || 'postgres://kohtaamiset:kohtaamiset@localhost:5432/kohtaamiset';

async function adminQuery(sql) {
  const c = new Client({ connectionString: BASE_URL });
  await c.connect();
  try { await c.query(sql); } finally { await c.end(); }
}

async function createTestDatabase() {
  const name = 'kohtaamiset_test_' + crypto.randomBytes(5).toString('hex');
  await adminQuery(`CREATE DATABASE ${name}`);
  const url = new URL(BASE_URL);
  url.pathname = '/' + name;
  process.env.DATABASE_URL = url.toString();
  await require('../../src/db').init();
  return async function dropTestDatabase() {
    await require('../../src/db').db.pool.end();
    await adminQuery(`DROP DATABASE IF EXISTS ${name} WITH (FORCE)`);
  };
}

module.exports = { createTestDatabase };
