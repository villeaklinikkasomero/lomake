'use strict';
// Unohtunut salasana: sähköpostilinkki (Mailgunin tilalla testipalvelin)
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const http = require('http');
const express = require('express');
const bcrypt = require('bcryptjs');

const { createTestDatabase } = require('./helpers/db');

// --- Mailgunin kaltainen testipalvelin: tallentaa lähetetyt viestit
const sent = [];
const mg = express();
mg.use(express.urlencoded({ extended: false }));
mg.post('/v3/:domain/messages', (req, res) => { sent.push(req.body); res.json({ id: 'x' }); });

let server, mgServer, base, db, dropDb;
before(async () => {
  mgServer = http.createServer(mg).listen(0); await new Promise(r => mgServer.once('listening', r));
  dropDb = await createTestDatabase();
  Object.assign(process.env, { MAILGUN_API_KEY: 'k', MAILGUN_DOMAIN: 'mg.test', MAILGUN_API_URL: `http://127.0.0.1:${mgServer.address().port}`, APP_URL: 'https://app.test' });
  const app = require('../src/server');
  db = require('../src/db').db;
  await db.run("INSERT INTO users (email, name, password_hash, role, auth_method, must_change_password) VALUES ('tunti@test.fi', 'Tunti', ?, 'tuntityontekija', 'local', 0)", bcrypt.hashSync('vanha-salasana-123', 4));
  await db.run("INSERT INTO users (email, name, password_hash, role, auth_method, must_change_password) VALUES ('ms@test.fi', 'MS', '!', 'hanketyontekija', 'entra', 0)");
  server = app.listen(0); await new Promise(r => server.once('listening', r));
  base = `http://127.0.0.1:${server.address().port}`;
});
after(async () => { server.close(); mgServer.close(); await dropDb(); });

const post = async (p, body) => {
  const res = await fetch(base + p, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'kohtaamiset' }, body: JSON.stringify(body) });
  return { status: res.status, data: await res.json() };
};
const waitMail = async (n) => { for (let i = 0; i < 50 && sent.length < n; i++) await new Promise(r => setTimeout(r, 20)); };
const tokenFrom = (mail) => mail.text.match(/#\/uusi-salasana\?t=([\w-]+)/)[1];

test('linkki sähköpostiin, uusi salasana, kertakäyttöisyys', async () => {
  assert.equal((await (await fetch(base + '/api/auth/config')).json()).passwordReset, true);

  const r = await post('/api/password/forgot', { email: 'tunti@test.fi' });
  assert.equal(r.status, 200);
  await waitMail(1);
  assert.equal(sent.length, 1);
  assert.equal(sent[0].to, 'tunti@test.fi');
  assert.match(sent[0].text, /^Hei Tunti,/);
  assert.ok(sent[0].text.includes('https://app.test/#/uusi-salasana?t='));
  const token = tokenFrom(sent[0]);
  // Kantaan ei tallenneta tunnistetta selväkielisenä
  assert.equal((await db.get('SELECT COUNT(*) AS n FROM password_resets WHERE token_hash = ?', token)).n, 0);

  assert.equal((await post('/api/password/reset', { token, password: 'lyhyt' })).status, 400);
  assert.equal((await post('/api/password/reset', { token: 'vaara', password: 'uusi-salasana-456' })).status, 400);
  assert.equal((await post('/api/password/reset', { token, password: 'uusi-salasana-456' })).status, 200);
  const u = await db.get("SELECT password_hash FROM users WHERE email = 'tunti@test.fi'");
  assert.ok(bcrypt.compareSync('uusi-salasana-456', u.password_hash));
  await waitMail(2);
  assert.match(sent[1].subject, /vaihdettu/);
  // Sama linkki ei toimi toista kertaa
  assert.equal((await post('/api/password/reset', { token, password: 'kolmas-salasana-789' })).status, 400);
});

test('sama vastaus tuntemattomalle ja Microsoft-tunnukselle, eikä viestiä lähetetä', async () => {
  const before = sent.length;
  const a = await post('/api/password/forgot', { email: 'eiole@test.fi' });
  const b = await post('/api/password/forgot', { email: 'ms@test.fi' });
  assert.deepEqual(a, b);
  assert.equal(a.status, 200);
  await new Promise(r => setTimeout(r, 100));
  assert.equal(sent.length, before);
});

test('vanhentunut linkki ja uusi pyyntö mitätöi edellisen', async () => {
  await post('/api/password/forgot', { email: 'tunti@test.fi' });
  await waitMail(sent.length + 1);
  const first = tokenFrom(sent.at(-1));
  await post('/api/password/forgot', { email: 'tunti@test.fi' });
  await waitMail(sent.length + 1);
  const second = tokenFrom(sent.at(-1));
  assert.equal((await post('/api/password/reset', { token: first, password: 'uusi-salasana-999' })).status, 400);
  await db.run('UPDATE password_resets SET expires = 0');
  assert.equal((await post('/api/password/reset', { token: second, password: 'uusi-salasana-999' })).status, 400);
});
