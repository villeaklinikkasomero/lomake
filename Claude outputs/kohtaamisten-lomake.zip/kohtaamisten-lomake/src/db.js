'use strict';
// Tietokantakerros (PostgreSQL 16). Skeema on tiedostossa migrations/001_init.sql.
//
// Kyselyt kirjoitetaan ?-paikkamerkeillä, jotka muunnetaan Postgresin $1, $2, … -muotoon:
//   await db.get(sql, ...params)  → ensimmäinen rivi tai undefined
//   await db.all(sql, ...params)  → rivit
//   await db.run(sql, ...params)  → { changes, rows }
//   await db.tx(async () => { … }) → transaktio. Sen sisällä kaikki db-kutsut (myös apufunktioissa,
//                                    kuten audit) käyttävät samaa yhteyttä. Poikkeus perii transaktion.

const { AsyncLocalStorage } = require('async_hooks');
const { Pool, types } = require('pg');
const bcrypt = require('bcryptjs');
const { migrate } = require('./migrate');

const IS_PROD = process.env.NODE_ENV === 'production';
const DATABASE_URL = process.env.DATABASE_URL || (IS_PROD ? null : 'postgres://kohtaamiset:kohtaamiset@localhost:5432/kohtaamiset');
if (!DATABASE_URL) throw new Error('DATABASE_URL puuttuu.');

// Tyypit JS-arvoiksi: luvut numeroina, päivämäärät ja aikaleimat merkkijonoina
// ('YYYY-MM-DD' ja 'YYYY-MM-DD HH:MM:SS', UTC), kuten sovellus ja Excel-vienti ne käsittelevät.
types.setTypeParser(types.builtins.INT8, (v) => parseInt(v, 10));
types.setTypeParser(types.builtins.NUMERIC, (v) => parseFloat(v));
types.setTypeParser(types.builtins.DATE, (v) => v);
types.setTypeParser(types.builtins.TIMESTAMP, (v) => v);

const pool = new Pool({
  connectionString: DATABASE_URL,
  max: Number(process.env.DATABASE_POOL_SIZE || 10),
  // Azure Database for PostgreSQL vaatii salatun yhteyden
  ssl: process.env.DATABASE_SSL === 'require' ? { rejectUnauthorized: true } : undefined,
  options: '-c TimeZone=UTC',
});
pool.on('error', (e) => console.error('Tietokantayhteyden virhe:', e.message));

const txClient = new AsyncLocalStorage();
const toPg = (sql) => { let i = 0; return sql.replace(/\?/g, () => '$' + (++i)); };
const query = (sql, params) => (txClient.getStore() || pool).query(toPg(sql), params);

const db = {
  get: async (sql, ...params) => (await query(sql, params)).rows[0],
  all: async (sql, ...params) => (await query(sql, params)).rows,
  run: async (sql, ...params) => { const r = await query(sql, params); return { changes: r.rowCount, rows: r.rows }; },
  async tx(fn) {
    if (txClient.getStore()) return fn();   // sisäkkäinen: jatketaan samassa transaktiossa
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const out = await txClient.run(client, fn);
      await client.query('COMMIT');
      return out;
    } catch (e) {
      await client.query('ROLLBACK').catch(() => {});
      throw e;
    } finally {
      client.release();
    }
  },
  pool,
};

// Lisäyksen id (INSERT … RETURNING id)
const insertId = async (sql, ...params) => (await db.run(sql + ' RETURNING id', ...params)).rows[0].id;

// ---------------------------------------------------------------------------
// Perusdata: hankkeet ja kysymykset Microsoft Forms -testiversion pohjalta
// (Kohtaamisten raportointi 2027, tila 29.10.2026).
// ---------------------------------------------------------------------------
const RECORDER_ROLES = [
  'A-klinikkasäätiön asiantuntija tai ohjaaja',
  'Tuntityöntekijä tai ulkopuolinen asiantuntija, ohjaaja, avustaja tai neuvontapalvelun vastaaja',
  'Vertainen, kokemusasiantuntija tai vapaaehtoinen',
];
const DIGITAL_LOCATION = 'Digialustalla';

// Kirjaustyyppien toimintatavat: määräävät lomakkeen määräkentät ja tilastoinnin
const RECORD_KINDS = {
  yksilo: 'Yksi kohtaaminen (määrä 1, asiakastunniste)',
  ryhma: 'Ryhmä tai useita kohtaamisia (kohtaamisten ja osallistujien määrä)',
  tavoittaminen: 'Tavoittaminen (tavoitettujen määrä, tilastoidaan erikseen)',
};

async function seedRecordTypes() {
  const types = [
    ['yksilo', 'Yksi kohtaaminen', 'Yksi henkilö, yksi keskustelu', 'yksilo', null, 10],
    ['ryhma', 'Ryhmä tai useita kohtaamisia', 'Ryhmä tai useampi kohtaaminen kerralla', 'ryhma', 'Kohtaamisten määrä', 20],
    ['tavoittaminen', 'Tavoittaminen', 'Koulutus, luento, webinaari tai muu yleisötilaisuus', 'tavoittaminen', 'Tavoitettujen määrä', 30],
  ];
  for (const t of types) {
    await db.run('INSERT INTO record_types (key, label, description, kind, count_label, sort) VALUES (?, ?, ?, ?, ?, ?) ON CONFLICT DO NOTHING', ...t);
  }
}

async function seed() {
  if ((await db.get('SELECT COUNT(*) AS n FROM projects')).n > 0) return;
  await db.tx(async () => {
    // Digipalveluiden värit ovat niiden verkkosivujen pääväreistä; muille säätiön väripaletista.
    const projects = [
      ['AK21', 'Ak21 Päihdelinkki ja Nuortenlinkki (sis. neuvontapalvelu)', 1, '#008900,#00a0f4'],
      ['DOPINGLINKKI', 'Dopinglinkki (sis. neuvontapalvelu)', 1, '#ffe000'],
      ['JALMA', 'Jalma', 0, '#00ea00'],
      ['KATUKLINIKKA', 'Katuklinikka', 0, '#0037d3'],
      ['LASINEN', 'Lasinen lapsuus', 1, '#a437b8'],
      ['OSIS', 'Osis (sis. vaparit)', 0, '#919396'],
      ['VOLJY', 'Völjy', 0, '#000000'],
    ];
    const pid = {};
    for (const [i, [code, name, digital, color]] of projects.entries()) {
      pid[code] = await insertId('INSERT INTO projects (code, name, sort, digital, color) VALUES (?, ?, ?, ?, ?)', code, name, (i + 1) * 10, digital, color);
    }

    await seedRecordTypes();

    const Y = ['yksilo'], YR = ['yksilo', 'ryhma'], T = ['tavoittaminen'];
    const PRO = { key: '_toteuttaja', values: [RECORDER_ROLES[0], RECORDER_ROLES[1]] };
    const q = (o) => {
      o = { project: null, help: null, options: null, required: 0, applies: null, show_if: null, min_value: null, digital_mode: 'show', suggest: 0, ...o };
      return db.run(`INSERT INTO questions (key, project_id, label, help, type, options, required, applies, show_if, min_value, free_text_warning, sort, digital_mode, suggest)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        o.key, o.project ? pid[o.project] : null, o.label, o.help, o.type, o.options ? JSON.stringify(o.options) : null, o.required ? 1 : 0,
        o.applies ? JSON.stringify(o.applies) : null, o.show_if ? JSON.stringify(o.show_if) : null, o.min_value,
        o.type === 'text' || o.type === 'textarea' ? 1 : 0, o.sort ?? 100, o.digital_mode, o.suggest);
    };
    // Yhteiset kysymykset (ydinkentät ajankohta, hanke, tyyppi, määrät ja kirjaajan rooli ovat
    // encounters-taulun omia sarakkeita). Tavoittamisessa ei kysytä kohtaamiskohtaisia tietoja.
    // Kaupunki ja kadunnimi piilotetaan, kun sijainti on Digialustalla.
    await q({ key: 'tavoittamisen_muoto', label: 'Tavoittamisen muoto', type: 'choice', options: ['Koulutus', 'Luento', 'Webinaari', 'Muu yleisötilaisuus'], required: 1, applies: T, sort: 5 });
    await q({ key: 'tyontekijan_arvio', label: 'Työntekijän arvio kohtaamisen hyödystä', type: 'rating', options: [1, 2, 3, 4, 5], required: 1, applies: YR, sort: 10 });
    await q({ key: 'asiakkaan_arvio', label: 'Asiakkaalta kysytty arvio kohtaamisen hyödystä',
      help: 'Jätä tyhjäksi, jos ei tiedossa tai jos asiakaspalaute kerätään eri lomakkeella tai työkalulla.', type: 'rating', options: [1, 2, 3, 4, 5], applies: Y, sort: 20 });
    await q({ key: 'myonteiset_seuraukset', label: 'Mitä myönteisiä seurauksia kohtaamisella arvioit olevan asiakkaalle?', type: 'multichoice', applies: Y, sort: 25,
      options: ['Asiakas sai tietoa tai ymmärrystä tilanteestaan', 'Asiakas koki tulleensa kuulluksi tai saaneensa tukea', 'Asiakkaan motivaatio tai valmius muutokseen vahvistui',
        'Asiakas löysi keinoja tilanteensa käsittelyyn', 'Asiakkaan hakeutuminen palveluihin tai tuen piiriin edistyi',
        'Asiakkaan elämäntilanteeseen liittyvä konkreettinen asia eteni tai ratkesi', 'Asiakkaan turvallisuus tai haittojen ehkäisy vahvistui'] });
    await q({ key: 'ika', label: 'Ikä (arvio)', help: 'Jos ei tiedossa, jätä tyhjäksi.', type: 'choice', applies: Y,
      options: ['0–7 vuotta', '8–17 vuotta', '18–29 vuotta', '30–62 vuotta', '63–79 vuotta', 'Yli 80 vuotta'], sort: 30 });
    await q({ key: 'sukupuoli', label: 'Oletettu sukupuoli', help: 'Jos ei tiedossa, jätä tyhjäksi.', type: 'choice', applies: Y,
      options: ['Nainen', 'Mies', 'Muu'], sort: 40 });
    await q({ key: 'sijainti', label: 'Kohtaamisen sijainti', type: 'choice', applies: YR,
      options: ['Kadulla tai muulla julkisella paikalla', 'Säätiön kohtaamispaikassa', 'Muussa sisätilassa', DIGITAL_LOCATION], sort: 50 });
    await q({ key: 'kaupunki', label: 'Kaupunki', help: 'Jätä tyhjäksi, jos kohtaaminen tai ryhmä toteutui digialustalla.', type: 'text', applies: YR,
      digital_mode: 'hide', suggest: 1, sort: 60 });
    await q({ key: 'kadunnimi', label: 'Kadunnimi, esim. Mannerheimintie, Kauppakatu',
      help: 'Jätä tyhjäksi, jos ei tiedossa tai kohtaaminen tapahtui digialustalla. Älä kirjoita koko osoitetta, esimerkiksi talon numeroa.', type: 'text', applies: YR,
      digital_mode: 'hide', suggest: 1, sort: 70 });
    await q({ key: 'asiakkaan_palaute', label: 'Asiakkaan tai ryhmän palaute', applies: YR,
      help: 'Jos asiakaspalautetta kerätään muulla työkalulla, voit kirjata tähän päällimmäiset kommentit tilanteesta.', type: 'textarea', sort: 80 });
    await q({ key: 'tyontekijan_huomiot', label: 'Työntekijän huomiot',
      help: 'Kirjaa esimerkiksi kohtaamisen välitön hyöty, olennaiset havainnot tai esiin nousseet ilmiöt.', type: 'textarea', sort: 90 });

    // Hankekohtaiset kysymykset (määrittelytaulukko "Kohtaamisten raportointi 2027 kysymykset ja huomiot")
    // Päihdelinkki ja Nuortenlinkki (AK21)
    await q({ key: 'ak21_palvelu', project: 'AK21', label: 'Mihin palveluun kohtaaminen liittyi?', type: 'choice', options: ['Päihdelinkki', 'Nuortenlinkki'], required: 1, applies: YR, sort: 10 });
    await q({ key: 'ak21_toimintamuoto_2027', project: 'AK21', label: 'Missä toimintamuodossa kohtaaminen toteutui?', type: 'choice', required: 1, applies: YR, sort: 20,
      options: ['Päivystyschat', 'Ajanvarauschat', 'Neuvontapalvelu', 'Jodel AMA', 'Walk in -videochat', 'Selvä suunta -ryhmä', 'Henkilökohtainen vertaistuki (Toivo)', 'Muu kohtaaminen'] });
    await q({ key: 'ak21_kenen_tilanne', project: 'AK21', label: 'Kenen tilanteeseen yhteydenotto liittyi?', type: 'choice', options: ['Oma tilanne', 'Läheisen tilanne', 'Muu / ei tiedossa'], applies: Y, sort: 30 });
    await q({ key: 'ak21_tuen_tarve', project: 'AK21', label: 'Mihin tuen tarpeeseen tai huoleen kohtaaminen liittyi?', type: 'multichoice', applies: Y, sort: 40,
      options: ['Alkoholi', 'Huumeet', 'Nikotiini', 'Rahapelaaminen', 'Muu riippuvuuskäyttäytyminen', 'Muu nuoren elämäntilanteeseen liittyvä huoli', 'Läheisen tilanne', 'Muu', 'Ei tiedossa'] });
    await q({ key: 'ak21_selkiytyminen', project: 'AK21', label: 'Selkiytyikö käyttäjän tilanne kohtaamisen aikana?', type: 'choice', options: ['Kyllä', 'Osittain', 'Ei'], required: 1, applies: Y, show_if: PRO, sort: 50 });
    await q({ key: 'ak21_seuraava_askel', project: 'AK21', label: 'Ilmaisiko käyttäjä aikomuksen ottaa seuraavan askeleen?', type: 'choice', options: ['Kyllä', 'Ehkä', 'Ei', 'Ei saatu tietoa'], applies: Y, show_if: PRO, sort: 60,
      help: 'Kirjaa käyttäjän ilmaisema aikomus, ei omaa oletustasi.' });
    // Dopinglinkki
    await q({ key: 'doping_kanava', project: 'DOPINGLINKKI', label: 'Missä kanavassa kohtaaminen toteutui?', type: 'choice', options: ['Verkkolomake', 'Viestisovellus', 'Live chat', 'Puhelin', 'Jodel AMA', 'Muu'], required: 1, applies: Y, sort: 10 });
    await q({ key: 'doping_tilanne', project: 'DOPINGLINKKI', label: 'Mikä on yhteydenottajan tilanne?', type: 'choice', applies: Y, sort: 20,
      options: ['Käyttää aineita', 'Harkitsee käytön aloittamista', 'Harkitsee lopettamista', 'Lopettanut käytön', 'Läheinen', 'Muu', 'Ei tiedossa'] });
    await q({ key: 'doping_aiheet', project: 'DOPINGLINKKI', label: 'Mitä aiheita kohtaaminen käsitteli?', type: 'multichoice', applies: Y, sort: 30,
      options: ['Aineiden vaikutukset ja riskit', 'Käytön aloittaminen', 'Käytön lopettaminen', 'Haittojen vähentäminen', 'Riippuvuus', 'Terveyshaitat', 'Läheisen tilanne', 'Hoitoon tai muuhun apuun hakeutuminen', 'Muu'] });
    await q({ key: 'doping_aineet', project: 'DOPINGLINKKI', label: 'Mitä aineita kohtaaminen käsitteli?', type: 'text', applies: Y, sort: 40 });
    await q({ key: 'doping_selkiytyminen', project: 'DOPINGLINKKI', label: 'Selkiytyikö kohdatun tilanne ja/tai löytyikö seuraava askel?', type: 'choice', options: ['Kyllä', 'Ei', 'Ei osaa arvioida'], required: 1, applies: Y, sort: 50 });
    // Jalma
    await q({ key: 'jalma_tukimuodot', project: 'JALMA', label: 'Mitä tukimuotoja nuoren kohtaamisessa toteutui?', type: 'multichoice', required: 1, applies: YR, sort: 10,
      options: ['Päihdeneuvonta', 'Mielenterveysneuvonta', 'Yksilöohjaus', 'Palveluohjaus', 'Psykososiaalinen tuki'] });
    await q({ key: 'jalma_ratkenneet', project: 'JALMA', label: 'Kuinka monta nuoren elämäntilanteen kannalta tärkeää asiaa ratkesi?', type: 'number', min_value: 0, required: 1, applies: YR, sort: 20 });
    await q({ key: 'jalma_etenemiset', project: 'JALMA', label: 'Minkälaisia konkreettisia etenemisiä tai ratkaisuja nuoren tilanteessa toteutui?', type: 'multichoice', required: 1, applies: YR, sort: 30,
      options: ['Palveluun pääsy', 'Hakemuksen tekeminen', 'Asumistilanteen eteneminen', 'Opiskeluun liittyvän tilanteen eteneminen', 'Työllistymiseen liittyvän tilanteen eteneminen', 'Muu konkreettinen eteneminen', 'Ei etenemistä tai ratkaisua'] });
    await q({ key: 'jalma_laheiset', project: 'JALMA', label: 'Kuinka monta tilaisuuden osallistujista oli nuoren läheisiä tai muita monikielisen yhteisön jäseniä?', type: 'number', min_value: 0, required: 1, applies: T, sort: 40 });
    await q({ key: 'jalma_ammattilaiset', project: 'JALMA', label: 'Kuinka monta tilaisuuden osallistujista oli nuorten kanssa työskenteleviä ammattilaisia?', type: 'number', min_value: 0, required: 1, applies: T, sort: 50 });
    // Katuklinikka
    await q({ key: 'katu_tukimuodot', project: 'KATUKLINIKKA', label: 'Mitä tukimuotoja kohtaamisessa toteutui?', type: 'multichoice', required: 1, applies: Y, sort: 10,
      options: ['Palveluohjaus', 'Saatto, kuljetus tai tuettu asiointi', 'Tiivis yksilötyöskentely', 'Haittoja vähentävä terveysneuvonta', 'Sosiaalineuvonta', 'Muu tuki'] });
    await q({ key: 'katu_luottamus', project: 'KATUKLINIKKA', label: 'Syntyikö tai vahvistuiko kohtaamisessa asiakkaan ja Katuklinikan välinen luottamuksellinen kontakti?', type: 'rating', options: [1, 2, 3, 4, 5], required: 1, applies: Y, sort: 20 });
    await q({ key: 'katu_palveluprosessi', project: 'KATUKLINIKKA', label: 'Edistikö Katuklinikan tuki asiakkaan palveluprosessin etenemistä tai jatkuvuutta?', type: 'rating', options: [1, 2, 3, 4, 5], applies: Y, sort: 30,
      help: 'Vastaa, jos kohtaaminen liittyi asiakkaan palveluprosessiin.' });
    await q({ key: 'katu_apu', project: 'KATUKLINIKKA', label: 'Saiko asiakas kohtaamisessa tarpeisiinsa vastaavaa apua tai tukea?', type: 'rating', options: [1, 2, 3, 4, 5], required: 1, applies: Y, sort: 40 });
    await q({ key: 'katu_haittojen_vahentaminen', project: 'KATUKLINIKKA', label: 'Saiko asiakas tietoa tai keinoja huumeiden käytöstä aiheutuvien haittojen vähentämiseen?', type: 'rating', options: [1, 2, 3, 4, 5], applies: Y, sort: 50,
      help: 'Vastaa, jos kohtaaminen liittyi haittojen vähentämiseen.' });
    // Lasinen lapsuus
    await q({ key: 'lasinen_toimintamuoto', project: 'LASINEN', label: 'Mihin Lasisen lapsuuden toimintamuotoon kirjaus liittyi?', type: 'choice', required: 1, sort: 10,
      options: ['Yksilötapaaminen', 'Anonyymi neuvontapalvelu', 'Suljettu vertaistukiryhmä', 'Toimiva ry:n kanssa järjestetty vertaistukiryhmä', 'Luova vertaistukiryhmä', 'Avoin ryhmächat',
        'Siruista sinuksi -keskusteluilta', 'Nuorten avoin vertaistapaaminen', 'Jatkoryhmä', 'AMA-tapahtuma', 'Hyvinvointituokio tai muu verkkotapahtuma', 'Kokemusasiantuntijoiden kehittämistyöpaja',
        'Ammattilais- tai opiskelijatapahtuma', 'Muu'] });
    // Osis: toimintamuoto ohjaa, mitkä lisäkysymykset näytetään
    const OSIS_YT = { key: 'osis_toimintamuoto', values: ['Yksilötuki'] };
    const OSIS_JV = { key: 'osis_toimintamuoto', values: ['Jalkautuva vapaaehtoistoiminta'] };
    await q({ key: 'osis_toimintamuoto', project: 'OSIS', label: 'Mitä Osiksen toimintamuotoa kirjaus koskee?', type: 'choice', required: 1, sort: 5,
      options: ['Yksilötuki', 'Vertaisvuoro', 'Jalkautuva vapaaehtoistoiminta', 'Muu toiminta'] });
    await q({ key: 'osis_kasitellyt_asiat', project: 'OSIS', label: 'Mitä asioita yksilötuessa käsiteltiin?', type: 'multichoice', required: 1, applies: YR, show_if: OSIS_YT, sort: 10,
      options: ['Palveluihin hakeutuminen tai palveluohjaus', 'Viranomaisasiointi', 'Asuminen tai asunnottomuus', 'Toimeentulo ja etuudet', 'Päihde- tai terveysasiat', 'Mielenterveys tai psykososiaalinen tuki', 'Muu arjen asia'] });
    await q({ key: 'osis_saatto', project: 'OSIS', label: 'Toteutuiko yksilötyössä saatto tai muu arjen asiointituki?', type: 'multichoice', required: 1, applies: YR, show_if: OSIS_YT, sort: 20,
      options: ['Saatto palveluun tai viranomaisasiointiin', 'Muu rinnalla kulkeminen tai asiointiapu', 'Ei toteutunut'] });
    await q({ key: 'osis_eteneminen', project: 'OSIS', label: 'Etenikö tai ratkesiko asiakkaalle merkityksellinen asia?', type: 'choice', required: 1, applies: YR, show_if: OSIS_YT, sort: 30,
      options: ['Eteni', 'Ratkesi', 'Ei edennyt tai ratkennut', 'Ei arvioitavissa'] });
    await q({ key: 'osis_vertaisvuorot', project: 'OSIS', label: 'Kuinka monta vertaisvuoroa kirjaukseen sisältyy?', type: 'number', min_value: 1, required: 1, show_if: { key: 'osis_toimintamuoto', values: ['Vertaisvuoro'] }, sort: 40 });
    await q({ key: 'osis_vapaaehtoiset', project: 'OSIS', label: 'Kuinka monta vapaaehtoista osallistui jalkautumiseen?', type: 'number', min_value: 0, required: 1, show_if: OSIS_JV, sort: 50 });
    await q({ key: 'osis_jalkautuminen_tuki', project: 'OSIS', label: 'Millaista tukea tai konkreettista apua jalkautumisessa annettiin?', type: 'multichoice', required: 1, show_if: OSIS_JV, sort: 60,
      options: ['Keskustelu tai kuuntelu', 'Ruoka tai juoma', 'Muu konkreettinen apu', 'Palveluohjaus tai ammatillinen tuki', 'Ei apua annettu'] });
    await q({ key: 'osis_ohjaus', project: 'OSIS', label: 'Ohjattiinko jalkautumisessa joku ammatilliseen tai kiireelliseen apuun?', type: 'choice', required: 1, show_if: OSIS_JV, sort: 70,
      options: ['Ammatilliseen apuun', 'Kiireelliseen apuun', 'Molempiin', 'Ei'] });
    // Völjy
    await q({ key: 'voljy_toimintamuoto', project: 'VOLJY', label: 'Mitä Völjyn toimintamuotoa kirjaus koskee?', type: 'choice', required: 1, applies: YR, sort: 10,
      options: ['Kohtaamispaikan toiminta', 'Kotiin vietävä tuki / kotikäynti', 'Yksilötyö tai palveluohjaus', 'Retki, ryhmä tai tapahtuma', 'Muu kohtaaminen'] });
    await q({ key: 'voljy_asumistuki', project: 'VOLJY', label: 'Annettiinko kohtaamisessa asumiseen liittyvää tukea?', type: 'choice', options: ['Kyllä', 'Ei'], required: 1, applies: YR, sort: 20 });
    const VA = { key: 'voljy_asumistuki', values: ['Kyllä'] };
    await q({ key: 'voljy_asuminen_toimenpiteet', project: 'VOLJY', label: 'Kuinka monta asumista turvaavaa toimenpidettä ratkesi tämän kirjauksen yhteydessä?', type: 'number', min_value: 0, required: 1, applies: YR, show_if: VA, sort: 30 });
    await q({ key: 'voljy_asuminen_tulos', project: 'VOLJY', label: 'Mikä asumista koskeva tulos toteutui tai varmistui?', type: 'multichoice', required: 1, applies: YR, show_if: VA, sort: 40,
      options: ['Häätö ehkäistiin', 'Vuokrasuhde säilyi / asuminen turvattiin', 'Uusi asumisratkaisu löytyi', 'Ei vielä varmistunutta tulosta'] });

    const services = ['Päihde- ja riippuvuuspalvelut', 'Terveysneuvonta tai terveyspalvelut', 'Mielenterveyspalvelut', 'Sosiaalipalvelut',
      'Asumispalvelut', 'Vertaistuki tai ryhmätoiminta', 'Säätiön toinen palvelu', 'Muu palvelu'];
    for (const [i, name] of services.entries()) await db.run('INSERT INTO referral_services (name, sort) VALUES (?, ?)', name, (i + 1) * 10);
  });
}

// ---------------------------------------------------------------------------
// Valmiit roolit ja niiden oletusoikeudet (ylläpidettävissä kohdassa Hallinta → Roolit).
// Lisätään vain, jos roolia ei vielä ole; admin-roolin oikeudet pidetään aina täysinä.
// ---------------------------------------------------------------------------
const BUILTIN_ROLES = [
  { key: 'admin', label: 'Admin', description: 'A-klinikkasäätiön työntekijä, pääkäyttäjä', recorder_index: 0, foundation: 1, sort: 10, permissions: {
    record: true, viewScope: 'all', editScope: 'all', deleteScope: 'all', exportScope: 'all', staffScope: 'all', pathScope: 'all', dashScope: 'all',
    manageUsers: true, manageProjects: true, manageQuestions: true } },
  { key: 'tiimivetaja', label: 'Tiiminvetäjä', description: 'A-klinikkasäätiön työntekijä', recorder_index: 0, foundation: 1, sort: 20, permissions: {
    record: true, viewScope: 'projects', editScope: 'projects', deleteScope: 'projects', exportScope: 'projects', staffScope: 'projects', pathScope: 'projects', dashScope: 'all',
    manageUsers: false, manageProjects: false, manageQuestions: false } },
  { key: 'hanketyontekija', label: 'Hanketyöntekijä', description: 'A-klinikkasäätiön työntekijä', recorder_index: 0, foundation: 1, sort: 30, permissions: {
    record: true, viewScope: 'own', editScope: 'own', deleteScope: 'none', exportScope: 'none', staffScope: 'own', pathScope: 'none', dashScope: 'all',
    manageUsers: false, manageProjects: false, manageQuestions: false } },
  { key: 'tuntityontekija', label: 'Tuntityöntekijä (avustaja)', description: 'Tuntityöntekijä tai avustaja', recorder_index: 1, foundation: 0, sort: 40, permissions: {
    record: true, viewScope: 'none', editScope: 'none', deleteScope: 'none', exportScope: 'none', staffScope: 'none', pathScope: 'none', dashScope: 'none',
    manageUsers: false, manageProjects: false, manageQuestions: false } },
];
async function seedRoles() {
  for (const r of BUILTIN_ROLES) {
    await db.run(`INSERT INTO roles (key, label, description, permissions, recorder_index, foundation, builtin, sort)
                  VALUES (?, ?, ?, ?, ?, ?, 1, ?) ON CONFLICT (key) DO NOTHING`,
      r.key, r.label, r.description, JSON.stringify(r.permissions), r.recorder_index, r.foundation, r.sort);
  }
  await db.run("UPDATE roles SET permissions = ?, active = 1 WHERE key = 'admin'", JSON.stringify(BUILTIN_ROLES[0].permissions));
}

// Kertaluonteiset tietomuutokset (merkitään settings-tauluun, ajetaan kerran)
async function once(name, fn) {
  if (await db.get('SELECT 1 FROM settings WHERE key = ?', 'migration.' + name)) return;
  await db.tx(async () => {
    await fn();
    await db.run('INSERT INTO settings (key, value) VALUES (?, ?)', 'migration.' + name, new Date().toISOString());
  });
}
async function dataMigrations() {
  // Kadunnimistä poistetaan talonumerot ja tarkennukset myös aiemmin tallennetuista kirjauksista
  await once('kadunnimi_ilman_numeroa', async () => {
    const { streetOnly } = require('./streets');
    const q = await db.get("SELECT id FROM questions WHERE key = 'kadunnimi'");
    if (!q) return;
    for (const r of await db.all('SELECT encounter_id, value FROM encounter_answers WHERE question_id = ?', q.id)) {
      const v = streetOnly(r.value);
      if (!v) await db.run('DELETE FROM encounter_answers WHERE encounter_id = ? AND question_id = ?', r.encounter_id, q.id);
      else if (v !== r.value) await db.run('UPDATE encounter_answers SET value = ? WHERE encounter_id = ? AND question_id = ?', v, r.encounter_id, q.id);
    }
  });
}

// Migraatiot ja perusdata. Kutsutaan kerran ennen kuin palvelin ottaa pyyntöjä vastaan.
const init = async () => {
  const applied = await migrate(pool, { afterMigrations: async () => { await seed(); await seedRoles(); await dataMigrations(); } });
  await require('./permissions').reload();
  return applied;
};

async function ensureAdmin() {
  if ((await db.get("SELECT COUNT(*) AS n FROM users WHERE role = 'admin'")).n > 0) return null;
  const email = process.env.ADMIN_EMAIL || 'admin@example.org';
  const password = process.env.ADMIN_PASSWORD || require('crypto').randomBytes(9).toString('base64url');
  await db.run(`INSERT INTO users (email, name, password_hash, role, must_change_password, recorder_role)
                VALUES (?, 'Pääkäyttäjä', ?, 'admin', 1, ?)`, email, bcrypt.hashSync(password, 12), RECORDER_ROLES[0]);
  return { email, password };
}

function audit(userId, action, entity, entityId, details) {
  return db.run('INSERT INTO audit_log (user_id, action, entity, entity_id, details) VALUES (?,?,?,?,?)',
    userId ?? null, action, entity ?? null, entityId == null ? null : String(entityId), details ? JSON.stringify(details) : null);
}

// ---------------------------------------------------------------------------
// Kytkettävät toiminnot (admin voi aktivoida Hallinta → Toiminnot).
// ---------------------------------------------------------------------------
const FEATURES = {
  paths: { label: 'Asiakaspolut', description: 'Asiakaspolkujen ja palveluohjausten koostenäkymä (admin ja tiiminvetäjä). Piilotettuna näkymä ja sen valikkolinkki eivät näy, eikä rajapinta palauta tietoja. Asiakastunnisteiden ja palveluohjausten kirjaaminen lomakkeella toimii tästä riippumatta.', default: false },
};
async function featureEnabled(key) {
  const r = await db.get('SELECT value FROM settings WHERE key = ?', 'feature.' + key);
  return r ? r.value === '1' : !!(FEATURES[key] && FEATURES[key].default);
}
function setFeature(key, on) {
  return db.run('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT (key) DO UPDATE SET value = excluded.value', 'feature.' + key, on ? '1' : '0');
}
const features = async () => Object.fromEntries(await Promise.all(Object.keys(FEATURES).map(async k => [k, await featureEnabled(k)])));

module.exports = { db, insertId, init, ensureAdmin, audit, RECORDER_ROLES, RECORD_KINDS, DIGITAL_LOCATION, FEATURES, featureEnabled, setFeature, features };
