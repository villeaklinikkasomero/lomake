'use strict';
// Raakadatan Excel-vienti.
//  - Yksi rivi = yksi lomaketallennus (ryhmäkirjaus säilyy yhtenä rivinä).
//  - Jokainen kysymys omassa sarakkeessaan (yhteiset + hankekohtaiset).
//  - Yksilökohtaamisten nimimerkkiä EI viedä (tietosuoja); eri henkilöiden
//    määrä näytetään vain ryhmäkirjauksille.
//  - Kirjaajan ja toteuttajan henkilöllisyyttä ei viedä, vain toteuttajan rooli.
//  - Palveluohjaukset vain, kun Asiakaspolut-toiminto on käytössä.

const ExcelJS = require('exceljs');
const { db, featureEnabled } = require('./db');

const TZ = 'Europe/Helsinki';
function utcToLocalDate(utc) {
  if (!utc) return null;
  // Excel ei tunne aikavyöhykkeitä: muodostetaan Helsingin paikallisaika "naiivina" päivämääränä.
  const d = new Date(utc.replace(' ', 'T') + 'Z');
  const parts = Object.fromEntries(new Intl.DateTimeFormat('en-GB', { timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }).formatToParts(d).map(p => [p.type, p.value]));
  return new Date(Date.UTC(+parts.year, +parts.month - 1, +parts.day, +parts.hour % 24, +parts.minute, +parts.second));
}
const dateOnly = (s) => { const [y, m, d] = s.split('-').map(Number); return new Date(Date.UTC(y, m - 1, d)); };

async function buildWorkbook({ from, to, projectIds }) {
  const ph = projectIds.map(() => '?').join(',');
  const performerLabels = Object.fromEntries((await db.all('SELECT key, label FROM performer_types')).map(r => [r.key, r.label]));
  const encounters = await db.all(`
    SELECT e.*, p.code AS project_code, p.name AS project_name
    FROM encounters e JOIN projects p ON p.id = e.project_id
    WHERE e.deleted_at IS NULL AND e.encounter_date BETWEEN ? AND ? AND e.project_id IN (${ph})
    ORDER BY e.encounter_date, e.created_at, e.id`, from, to, ...projectIds);

  // Sarakkeiksi kaikki aktiiviset kysymykset + käytöstä poistetut, joihin on vastauksia aineistossa.
  const questions = await db.all(`
    SELECT q.*, p.name AS project_name FROM questions q LEFT JOIN projects p ON p.id = q.project_id
    WHERE (q.project_id IS NULL OR q.project_id IN (${ph}))
      AND (q.active = 1 OR EXISTS (SELECT 1 FROM encounter_answers a JOIN encounters e ON e.id = a.encounter_id
                                  WHERE a.question_id = q.id AND e.deleted_at IS NULL AND e.encounter_date BETWEEN ? AND ?))
    ORDER BY q.project_id IS NOT NULL, p.sort, q.sort, q.id`, ...projectIds, from, to);

  // Ohjaukset kirjauksittain (palveluiden nimet). Asiakastunnistetta ei viedä.
  const refMap = new Map();
  if (encounters.length) {
    const rs = await db.all(`SELECT r.encounter_id, string_agg(s.name, '; ' ORDER BY s.sort, s.name) AS services FROM referrals r JOIN referral_services s ON s.id = r.service_id
                           JOIN encounters e ON e.id = r.encounter_id
                           WHERE e.deleted_at IS NULL AND e.encounter_date BETWEEN ? AND ? AND e.project_id IN (${ph}) GROUP BY r.encounter_id`, from, to, ...projectIds);
    for (const r of rs) refMap.set(r.encounter_id, r.services);
  }
  const answers = new Map();
  if (encounters.length) {
    const rows = await db.all(`SELECT a.encounter_id, a.question_id, a.value FROM encounter_answers a
                               JOIN encounters e ON e.id = a.encounter_id
                               WHERE e.deleted_at IS NULL AND e.encounter_date BETWEEN ? AND ? AND e.project_id IN (${ph})`, from, to, ...projectIds);
    for (const a of rows) {
      if (!answers.has(a.encounter_id)) answers.set(a.encounter_id, {});
      answers.get(a.encounter_id)[a.question_id] = a.value;
    }
  }

  const typeLabels = Object.fromEntries((await db.all('SELECT key, label FROM record_types')).map(t => [t.key, t.label]));
  const wb = new ExcelJS.Workbook();
  wb.creator = 'Kohtaamisten raportointi';
  wb.created = new Date();
  const ws = wb.addWorksheet('Kohtaamiset', { views: [{ state: 'frozen', ySplit: 1 }] });

  const base = [
    { header: 'Tunniste', key: 'id', width: 38 },
    { header: 'Kohtaamisen ajankohta', key: 'encounter_date', width: 14, style: { numFmt: 'd.m.yyyy' } },
    { header: 'Hanke', key: 'project_name', width: 32 },
    { header: 'Hanketunnus', key: 'project_code', width: 14 },
    { header: 'Toteuttajan rooli', key: 'recorder_role', width: 40 },
    { header: 'Toteuttaja', key: 'performer', width: 18 },
    { header: 'Kirjattu toisen puolesta', key: 'on_behalf', width: 12 },
    { header: 'Kirjauksen tyyppi', key: 'encounter_type', width: 22 },
    { header: 'Kohtaamisten määrä', key: 'encounter_count', width: 12 },
    { header: 'Tavoitettujen määrä', key: 'reach_count', width: 12 },
    { header: 'Eri henkilöiden määrä (ryhmä)', key: 'person_count', width: 14 },
    { header: 'Tunnistettu asiakas (yksilö)', key: 'client_linked', width: 14 },
    ...((await featureEnabled('paths')) ? [{ header: 'Ohjattu palveluun', key: 'referrals', width: 36 }] : []),
  ];
  const qCols = questions.map(q => ({
    header: q.project_id ? `${q.project_name}: ${q.label}` : q.label,
    key: 'q_' + q.id, width: q.type === 'textarea' ? 50 : Math.min(Math.max(q.label.length, 12), 40),
  }));
  const tail = [
    { header: 'Tallennettu', key: 'created_at', width: 18, style: { numFmt: 'd.m.yyyy h:mm' } },
    { header: 'Muokattu', key: 'updated_at', width: 18, style: { numFmt: 'd.m.yyyy h:mm' } },
    { header: 'Testidata', key: 'is_test', width: 10 },
  ];
  ws.columns = [...base, ...qCols, ...tail];

  for (const e of encounters) {
    const row = {
      id: e.id,
      encounter_date: dateOnly(e.encounter_date),
      project_name: e.project_name,
      project_code: e.project_code,
      recorder_role: e.recorder_role,
      performer: e.performer_type === 'kayttaja' ? 'Työntekijä' : (performerLabels[e.performer_type] || e.performer_type),
      on_behalf: e.performer_type !== 'kayttaja' || (e.performed_by != null && e.performed_by !== e.created_by) ? 'kyllä' : 'ei',
      encounter_type: typeLabels[e.encounter_type] || e.encounter_type,
      encounter_count: e.kind === 'tavoittaminen' ? null : e.encounter_count,
      reach_count: e.kind === 'tavoittaminen' ? e.encounter_count : null,
      person_count: e.kind === 'ryhma' ? e.person_count : null,
      client_linked: e.kind === 'yksilo' ? (e.client_id ? 'kyllä' : 'ei') : null,
      referrals: refMap.get(e.id) || null,
      created_at: utcToLocalDate(e.created_at),
      updated_at: utcToLocalDate(e.updated_at),
      is_test: e.is_test ? 'kyllä' : 'ei',
    };
    const ans = answers.get(e.id) || {};
    for (const q of questions) {
      const v = ans[q.id];
      if (v == null) continue;
      if (q.type === 'multichoice') row['q_' + q.id] = JSON.parse(v).join('; ');
      else if (q.type === 'rating' || q.type === 'number') row['q_' + q.id] = Number(v);
      else if (q.type === 'date') row['q_' + q.id] = dateOnly(v);
      else row['q_' + q.id] = v;
    }
    ws.addRow(row);
  }

  const header = ws.getRow(1);
  header.font = { bold: true, color: { argb: 'FFFFFFFF' } };
  header.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1F4E79' } };
  header.alignment = { vertical: 'middle', wrapText: true };
  header.height = 36;
  ws.autoFilter = { from: { row: 1, column: 1 }, to: { row: 1, column: ws.columns.length } };

  // Selitesivu: sarakkeiden pysyvät tunnisteet (Power BI / jatkoanalyysi).
  const info = wb.addWorksheet('Sarakkeet');
  info.columns = [
    { header: 'Sarake', key: 'header', width: 50 },
    { header: 'Pysyvä tunniste', key: 'key', width: 26 },
    { header: 'Hanke', key: 'project', width: 30 },
    { header: 'Tyyppi', key: 'type', width: 14 },
    { header: 'Koskee', key: 'applies', width: 12 },
    { header: 'Käytössä', key: 'active', width: 10 },
  ];
  info.getRow(1).font = { bold: true };
  for (const c of base) info.addRow({ header: c.header, key: c.key, project: 'Yhteinen', type: 'perustieto', applies: 'kaikki', active: 'kyllä' });
  questions.forEach((q, i) => info.addRow({ header: qCols[i].header, key: q.key, project: q.project_name || 'Yhteinen', type: q.type,
    applies: q.applies ? JSON.parse(q.applies).map(k => typeLabels[k] || k).join('; ') : 'kaikki', active: q.active ? 'kyllä' : 'ei' }));
  info.addRow({});
  info.addRow({ header: `Aikaväli ${from} – ${to}. Rivejä ${encounters.length}, kohtaamisia yhteensä ${encounters.reduce((s, e) => s + e.encounter_count, 0)}.` });
  info.addRow({ header: 'Asiakastunnisteet (nimimerkit) eivät sisälly vientiin tietosuojasyistä. Sarake ”Tunnistettu asiakas” kertoo vain, käytettiinkö tunnistetta.' });

  return wb;
}

module.exports = { buildWorkbook };
