'use strict';
// Tilastonäkymän (dashboard) koosteet. Vain koottuja lukuja – ei tunnisteita,
// nimimerkkejä eikä vapaatekstejä.

const { db, RECORDER_ROLES } = require('./db');

const qid = async (key) => ((await db.get('SELECT id FROM questions WHERE key = ?', key)) || {}).id || -1;

function shiftPeriod(from, to) {
  // Edellinen yhtä pitkä jakso juuri ennen valittua aikaväliä
  const f = new Date(from + 'T00:00:00Z'), t = new Date(to + 'T00:00:00Z');
  const days = Math.round((t - f) / 86400000) + 1;
  const pt = new Date(f.getTime() - 86400000), pf = new Date(f.getTime() - days * 86400000);
  return [pf.toISOString().slice(0, 10), pt.toISOString().slice(0, 10)];
}

// Sama jakso vuotta aiemmin (29.2. → 28.2.)
function shiftYear(from, to) {
  const back = (d) => { const [y, m, dd] = d.split('-').map(Number); const last = new Date(Date.UTC(y - 1, m, 0)).getUTCDate();
    return `${y - 1}-${String(m).padStart(2, '0')}-${String(Math.min(dd, last)).padStart(2, '0')}`; };
  return [back(from), back(to)];
}

async function buildWhere({ from, to, projectIds, projectId, types, role, ika, sukupuoli, kaupunki }) {
  const w = ['e.deleted_at IS NULL', `e.project_id IN (${projectIds.map(() => '?').join(',') || 'NULL'})`];
  const p = [...projectIds];
  if (from) { w.push('e.encounter_date >= ?'); p.push(from); }
  if (to) { w.push('e.encounter_date <= ?'); p.push(to); }
  if (projectId) { w.push('e.project_id = ?'); p.push(projectId); }
  if (types && types.length) {
    const all = (await db.get('SELECT COUNT(*) AS n FROM record_types')).n;
    if (types.length < all) { w.push(`e.encounter_type IN (${types.map(() => '?').join(',')})`); p.push(...types); }
  }
  if (role) { w.push('e.recorder_role = ?'); p.push(role); }
  for (const [key, val] of [['ika', ika], ['sukupuoli', sukupuoli]]) {
    if (!val) continue;
    w.push('EXISTS (SELECT 1 FROM encounter_answers a WHERE a.encounter_id = e.id AND a.question_id = ? AND a.value = ?)');
    p.push(await qid(key), val);
  }
  if (kaupunki) {
    w.push('EXISTS (SELECT 1 FROM encounter_answers a WHERE a.encounter_id = e.id AND a.question_id = ? AND lower(trim(a.value)) = ?)');
    p.push(await qid('kaupunki'), String(kaupunki).trim().toLowerCase());
  }
  return { sql: w.join(' AND '), params: p };
}

// Paikkakunnat ja kadut (vapaatekstiä: kirjoitusasut yhdistetään kirjainkoosta ja välilyönneistä riippumatta).
// Näytettäväksi nimeksi valitaan yleisin kirjoitusasu.
async function places(filters, W) {
  const cq = await qid('kaupunki'), sq = await qid('kadunnimi');
  const ENCOUNTERS = "SUM(CASE WHEN e.kind <> 'tavoittaminen' THEN e.encounter_count ELSE 0 END)";
  const merge = (rows, keyOf) => {
    const m = new Map();
    for (const r of rows) {
      const key = keyOf(r); const o = m.get(key) || { label: r.v, best: 0, rows: 0, encounters: 0, city: r.cv || null };
      o.rows += r.rows; o.encounters += r.encounters;
      if (r.rows > o.best) { o.best = r.rows; o.label = r.v; if (r.cv) o.city = r.cv; }
      m.set(key, o);
    }
    return [...m.values()].sort((a, b) => b.encounters - a.encounters || a.label.localeCompare(b.label, 'fi'));
  };
  // Paikkakunnat ilman paikkakuntarajausta (rajaus valitsee yhden niistä)
  const WC = await buildWhere({ ...filters, kaupunki: null });
  const cityRows = await db.all(`SELECT lower(trim(a.value)) AS k, trim(a.value) AS v, COUNT(*) AS rows, ${ENCOUNTERS} AS encounters
    FROM encounters e JOIN encounter_answers a ON a.encounter_id = e.id AND a.question_id = ?
    WHERE ${WC.sql} AND trim(a.value) <> '' GROUP BY k, v`, cq, ...WC.params);
  const cities = merge(cityRows, r => r.k);
  const totalEnc = (await db.get(`SELECT COALESCE(SUM(CASE WHEN e.kind <> 'tavoittaminen' THEN e.encounter_count END), 0) AS n
    FROM encounters e WHERE ${WC.sql}`, ...WC.params)).n;
  const withCity = cities.reduce((t, c) => t + c.encounters, 0);
  const streetRows = await db.all(`SELECT lower(trim(a.value)) AS k, trim(a.value) AS v, lower(trim(c.value)) AS ck, trim(c.value) AS cv,
      COUNT(*) AS rows, ${ENCOUNTERS} AS encounters
    FROM encounters e JOIN encounter_answers a ON a.encounter_id = e.id AND a.question_id = ?
    LEFT JOIN encounter_answers c ON c.encounter_id = e.id AND c.question_id = ?
    WHERE ${W.sql} AND trim(a.value) <> '' GROUP BY k, v, ck, cv`, sq, cq, ...W.params);
  const streets = merge(streetRows, r => r.k + '|' + (filters.kaupunki ? '' : (r.ck || '')));
  const strip = (x) => ({ label: x.label, city: x.city, rows: x.rows, encounters: x.encounters });
  return {
    cities: cities.map(strip), withoutCity: Math.max(0, totalEnc - withCity),
    streets: streets.slice(0, 20).map(strip), streetCount: streets.length,
  };
}

async function totals(W) {
  // Kohtaamiset = yksilö- ja ryhmätyyppiset kirjaukset; tavoittaminen tilastoidaan erikseen (reach)
  const t = await db.get(`SELECT COUNT(*) AS rows,
      COALESCE(SUM(CASE WHEN e.kind <> 'tavoittaminen' THEN e.encounter_count END), 0) AS encounters,
      COALESCE(SUM(CASE WHEN e.kind = 'tavoittaminen' THEN e.encounter_count END), 0) AS reach,
      COUNT(*) FILTER (WHERE e.kind = 'tavoittaminen') AS reach_rows,
      COALESCE(SUM(CASE WHEN e.kind = 'yksilo' THEN e.encounter_count END), 0) AS yksilo,
      COALESCE(SUM(CASE WHEN e.kind = 'ryhma' THEN e.encounter_count END), 0) AS ryhma,
      COUNT(DISTINCT e.client_id) AS identified,
      COALESCE(SUM(CASE WHEN e.kind = 'ryhma' THEN e.person_count END), 0) AS group_persons,
      COUNT(*) FILTER (WHERE e.kind = 'yksilo' AND e.client_id IS NULL) AS unidentified,
      COUNT(*) FILTER (WHERE e.kind = 'ryhma' AND e.person_count IS NULL) AS groups_without_count,
      -- Täysin anonyymit kohtaamiset: yksilö ilman nimimerkkiä + ryhmien kohtaamiset, joista osallistujamäärä puuttuu.
      -- Näistä ei voi päätellä eri henkilöiden määrää, joten ne jäävät arvion ulkopuolelle.
      COALESCE(SUM(CASE WHEN e.kind = 'yksilo' AND e.client_id IS NULL THEN e.encounter_count END), 0) AS anon_individual,
      COALESCE(SUM(CASE WHEN e.kind = 'ryhma' AND e.person_count IS NULL THEN e.encounter_count END), 0) AS anon_group
    FROM encounters e WHERE ${W.sql}`, ...W.params);
  // Eri henkilöiden arvio = tunnistetut asiakkaat + ryhmien ilmoitetut osallistujat
  t.persons = t.identified + t.group_persons;
  t.anonymous = t.anon_individual + t.anon_group;
  t.anonymous_share = t.encounters ? t.anonymous / t.encounters : null;
  return t;
}

async function dashboard(filters) {
  const W = await buildWhere(filters);
  const cur = await totals(W);
  // Vertailu valinnan mukaan: ei vertailua, edellinen yhtä pitkä jakso tai sama jakso vuotta aiemmin
  const compare = ['prev', 'year'].includes(filters.compare) ? filters.compare : 'none';
  const [pf, pt] = compare === 'year' ? shiftYear(filters.from, filters.to) : shiftPeriod(filters.from, filters.to);
  const PW = compare === 'none' ? null : await buildWhere({ ...filters, from: pf, to: pt });
  const prev = PW ? await totals(PW) : null;

  const monthlyFor = (w) => db.all(`SELECT to_char(e.encounter_date, 'YYYY-MM') AS month, COUNT(*) AS rows,
      COALESCE(SUM(CASE WHEN e.kind <> 'tavoittaminen' THEN e.encounter_count END), 0) AS encounters,
      COALESCE(SUM(CASE WHEN e.kind = 'tavoittaminen' THEN e.encounter_count END), 0) AS reach,
      COALESCE(SUM(CASE WHEN e.kind = 'yksilo' THEN e.encounter_count END), 0) AS yksilo,
      COALESCE(SUM(CASE WHEN e.kind = 'ryhma' THEN e.encounter_count END), 0) AS ryhma
    FROM encounters e WHERE ${w.sql} GROUP BY month ORDER BY month`, ...w.params);
  const monthly = await monthlyFor(W);
  const monthlyPrev = PW ? await monthlyFor(PW) : null;

  const byProject = await db.all(`SELECT p.id, p.name, COUNT(*) AS rows,
      COALESCE(SUM(CASE WHEN e.kind <> 'tavoittaminen' THEN e.encounter_count END), 0) AS encounters,
      COALESCE(SUM(CASE WHEN e.kind = 'tavoittaminen' THEN e.encounter_count END), 0) AS reach
    FROM encounters e JOIN projects p ON p.id = e.project_id WHERE ${W.sql} GROUP BY p.id ORDER BY encounters DESC`, ...W.params);
  // Kirjaustyypeittäin (kohtaamiset ja tavoitetut)
  const byType = await db.all(`SELECT e.encounter_type AS key, rt.label, rt.kind, COUNT(*) AS rows, SUM(e.encounter_count) AS count
    FROM encounters e LEFT JOIN record_types rt ON rt.key = e.encounter_type
    WHERE ${W.sql} GROUP BY e.encounter_type, rt.label, rt.kind, rt.sort ORDER BY rt.sort`, ...W.params);

  const ratingStats = async (key) => {
    const id = await qid(key);
    const r = await db.get(`SELECT AVG(CAST(a.value AS REAL)) AS avg, COUNT(*) AS n FROM encounters e
      JOIN encounter_answers a ON a.encounter_id = e.id AND a.question_id = ? WHERE ${W.sql}`, id, ...W.params);
    const dist = await db.all(`SELECT a.value AS v, COUNT(*) AS n FROM encounters e JOIN encounter_answers a ON a.encounter_id = e.id AND a.question_id = ?
      WHERE ${W.sql} GROUP BY a.value`, id, ...W.params);
    return { avg: r.avg, n: r.n, dist: [1, 2, 3, 4, 5].map(v => ({ value: v, n: (dist.find(d => Number(d.v) === v) || { n: 0 }).n })) };
  };

  // Vastausjakaumat valinta- ja arviokysymyksistä (yhteiset + valitun hankkeen omat)
  const qs = await db.all(`SELECT q.*, p.name AS project_name FROM questions q LEFT JOIN projects p ON p.id = q.project_id
    WHERE q.type IN ('choice', 'multichoice', 'rating') AND q.key NOT IN ('tyontekijan_arvio', 'asiakkaan_arvio')
      AND (q.project_id IS NULL OR q.project_id = ?) ORDER BY q.project_id IS NOT NULL, q.sort, q.id`, filters.projectId || -1);
  const distributions = [];
  for (const q of qs) {
    const rows = await db.all(`SELECT a.value FROM encounters e JOIN encounter_answers a ON a.encounter_id = e.id AND a.question_id = ?
      WHERE ${W.sql}`, q.id, ...W.params);
    if (!rows.length) continue;
    const counts = new Map();
    for (const r of rows) {
      const vals = q.type === 'multichoice' ? JSON.parse(r.value) : [r.value];
      for (const v of vals) counts.set(v, (counts.get(v) || 0) + 1);
    }
    const options = q.type === 'rating' ? ['1', '2', '3', '4', '5'] : JSON.parse(q.options || '[]');
    const items = options.map(o => ({ label: String(o), value: counts.get(String(o)) || 0 }));
    for (const [k, v] of counts) if (!options.map(String).includes(k)) items.push({ label: k, value: v }); // poistuneet vaihtoehdot
    distributions.push({ key: q.key, label: q.label, project: q.project_name || null, multiple: q.type === 'multichoice', answered: rows.length, items });
  }

  const ref = await db.get(`SELECT COUNT(*) AS total, COUNT(*) FILTER (WHERE r.status = 'toteutui') AS toteutui,
      COUNT(*) FILTER (WHERE r.status = 'ei_toteutunut') AS ei_toteutunut, COUNT(*) FILTER (WHERE r.status = 'avoin') AS avoin
    FROM referrals r JOIN encounters e ON e.id = r.encounter_id WHERE ${W.sql}`, ...W.params);

  const updated = (await db.get(`SELECT MAX(COALESCE(e.updated_at, e.created_at)) AS t FROM encounters e WHERE ${W.sql}`, ...W.params)).t;

  const opt = async (key) => { const q = await db.get('SELECT options FROM questions WHERE key = ?', key); return q && q.options ? JSON.parse(q.options) : []; };
  return {
    period: { from: filters.from, to: filters.to, compare, prevFrom: PW ? pf : null, prevTo: PW ? pt : null },
    totals: cur, previous: prev, monthly, monthlyPrev, byProject, byType,
    ratings: { worker: await ratingStats('tyontekijan_arvio'), client: await ratingStats('asiakkaan_arvio') },
    referrals: { ...ref, rate: ref.toteutui + ref.ei_toteutunut ? ref.toteutui / (ref.toteutui + ref.ei_toteutunut) : null },
    distributions, updated, places: await places(filters, W),
    options: { roles: RECORDER_ROLES, ika: await opt('ika'), sukupuoli: await opt('sukupuoli') },
  };
}

module.exports = { dashboard, shiftPeriod, shiftYear };
