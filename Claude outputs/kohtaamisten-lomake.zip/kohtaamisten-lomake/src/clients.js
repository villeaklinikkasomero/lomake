'use strict';
// Asiakastunnisteet ja palveluohjaukset.
//
// Tietosuoja:
//  - Asiakkaan nimimerkkiä tai tunnusta EI tallenneta tietokantaan. Siitä
//    tallennetaan vain HMAC-SHA256-tiiviste, joka lasketaan palvelimen
//    ympäristömuuttujassa olevalla avaimella (PSEUDONYM_KEY). Pelkällä
//    tietokannalla (esim. varmuuskopio tai vuoto) tunnisteita ei voi palauttaa
//    eikä arvata.
//  - Tunniste on HANKEKOHTAINEN: hanke on mukana tiivisteen laskennassa, joten
//    saman nimimerkin tiivisteet eri hankkeissa eivät ole yhdistettävissä.
//    Hankkeen sisällä kaksi asiakasta ei voi saada samaa tunnistetta.
//    Hankkeiden välistä asiakaslinkitystä ei ole.
//  - Linkitys katkaistaan automaattisesti, kun asiakasta ei ole kohdattu
//    CLIENT_RETENTION_MONTHS kuukauteen (oletus 24).
//  - Avainta EI saa vaihtaa käytön aikana: vaihto katkaisee kaikki linkitykset.

const crypto = require('crypto');
const { db, insertId, audit } = require('./db');

const IS_PROD = process.env.NODE_ENV === 'production';
const DEV_KEY = 'kehitys-avain-ei-tuotantoon';
const KEY = process.env.PSEUDONYM_KEY || (IS_PROD ? null : DEV_KEY);
const ENABLED = !!KEY && KEY.length >= 16;
const RETENTION_MONTHS = Number(process.env.CLIENT_RETENTION_MONTHS || 24);

// --- Tunnisteen käsittely -----------------------------------------------------
// Vakiointi: Unicode-normalisointi, pienet kirjaimet, vain kirjaimet ja numerot.
// "Kettu 88", "kettu88" ja "KETTU-88" ovat sama tunniste.
function normalize(ref) {
  return String(ref || '').normalize('NFKC').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '');
}
// Lisäksi ääkköset ja muut tarkkeet ohitetaan: "Mäyrä", "Mayra" ja "MÄYRÄ" ovat sama tunniste
// (puhelimella tai vieraalla näppäimistöllä ääkköset jäävät helposti pois).
function fold(ref) {
  return normalize(ref).normalize('NFD').replace(/\p{M}+/gu, '').normalize('NFC');
}
// Hankekohtainen tiiviste: sama nimimerkki eri hankkeissa → eri tiiviste
function hashRef(projectId, ref) {
  return crypto.createHmac('sha256', KEY).update(`asiakas:p${Number(projectId)}:` + fold(ref)).digest('hex');
}
// Satunnainen nimimerkki kahdesta sanasta (adjektiivi + luonnosta tai eläimistä), esim. "Sininen Kettu".
// Sanat on valittu neutraaleiksi: ei henkilönnimiä, yleisiä sukunimiä, arvottavia eikä arkaluonteisia sanoja.
const ADJECTIVES = ['Sininen', 'Vihreä', 'Punainen', 'Keltainen', 'Kultainen', 'Hopeinen', 'Iloinen', 'Rohkea', 'Nopea', 'Kirkas',
  'Lempeä', 'Tumma', 'Vaalea', 'Utelias', 'Vikkelä', 'Viisas', 'Reipas', 'Tyyni', 'Raikas', 'Lämmin', 'Kesäinen', 'Talvinen',
  'Syksyinen', 'Keväinen', 'Pehmeä', 'Vahva', 'Ketterä', 'Hohtava', 'Leikkisä', 'Sitkeä', 'Uljas', 'Valoisa', 'Villi',
  'Rauhallinen', 'Pirteä', 'Notkea', 'Tähtinen', 'Huurteinen', 'Aurinkoinen', 'Sumuinen', 'Tuulinen', 'Ripeä', 'Hellä',
  'Sinertävä', 'Vehreä', 'Kuulas', 'Ystävällinen', 'Oranssi', 'Violetti', 'Turkoosi'];
const NOUNS = ['Kettu', 'Karhu', 'Ilves', 'Jänis', 'Orava', 'Siili', 'Pöllö', 'Haukka', 'Joutsen', 'Kurki', 'Lokki', 'Harakka',
  'Tikka', 'Peippo', 'Sorsa', 'Hirvi', 'Majava', 'Saukko', 'Hylje', 'Hauki', 'Ahven', 'Muikku', 'Mäyrä', 'Näätä', 'Kärppä',
  'Myyrä', 'Sammakko', 'Perhonen', 'Kimalainen', 'Leppäkerttu', 'Kuu', 'Pilvi', 'Tuuli', 'Lumihiutale', 'Sateenkaari',
  'Revontuli', 'Puro', 'Metsä', 'Mänty', 'Pihlaja', 'Vaahtera', 'Kanerva', 'Mustikka', 'Puolukka', 'Mansikka', 'Vadelma',
  'Omena', 'Sammal', 'Niitty', 'Kukkula', 'Tunturi', 'Majakka', 'Kompassi', 'Purjevene', 'Lyhty', 'Kanootti', 'Käpy',
  'Simpukka', 'Meritähti', 'Delfiini', 'Pingviini', 'Kameli', 'Seepra', 'Koala', 'Pandakarhu', 'Tiikeri', 'Kilpikonna'];
function newCode(withNumber) {
  const pick = (arr) => arr[crypto.randomInt(arr.length)];
  return `${pick(ADJECTIVES)} ${pick(NOUNS)}` + (withNumber ? ` ${crypto.randomInt(2, 100)}` : '');
}
function validateRef(ref, sensitiveHit) {
  const n = normalize(ref);
  if (n.length < 3) return 'Tunnisteen on oltava vähintään 3 merkkiä (kirjaimia tai numeroita).';
  if (n.length > 40) return 'Tunniste on liian pitkä.';
  if (sensitiveHit && sensitiveHit(String(ref))) return 'Tunniste näyttää sisältävän tunnistetietoja. Älä käytä oikeaa nimeä, henkilötunnusta tai yhteystietoja.';
  return null;
}

// Hakee asiakkaan hankkeen sisältä
function findClient(projectId, ref) {
  return db.get('SELECT * FROM clients WHERE project_id = ? AND ref_hash = ?', projectId, hashRef(projectId, ref));
}

async function generateUniqueCode(projectId) {
  // Ensin pelkät sanat; jos hankkeessa on jo paljon asiakkaita, lisätään loppuun numero
  for (let i = 0; i < 40; i++) { const c = newCode(i >= 25); if (!(await findClient(projectId, c))) return c; }
  throw new Error('Tunnuksen luonti epäonnistui.');
}

// Palaavan asiakkaan yhteenveto kirjaajalle. Näytetään vain avoimet ohjaukset
// (palvelu ja päivämäärä), ei muiden hankkeiden vapaatekstejä tai muita tietoja.
async function clientSummary(clientId) {
  const s = await db.get(`SELECT COUNT(*) AS encounters, MIN(encounter_date) AS first_date, MAX(encounter_date) AS last_date
                          FROM encounters WHERE client_id = ? AND deleted_at IS NULL`, clientId);
  const open = await db.all(`SELECT r.id, r.referred_on, rs.name AS service FROM referrals r
                             JOIN referral_services rs ON rs.id = r.service_id
                             JOIN encounters e ON e.id = r.encounter_id AND e.deleted_at IS NULL
                             WHERE r.client_id = ? AND r.status = 'avoin' ORDER BY r.referred_on`, clientId);
  return { encounters: s.encounters, first_month: s.first_date ? s.first_date.slice(0, 7) : null,
           last_date: s.last_date, open_referrals: open };
}

/**
 * Tarkistaa lomakkeen asiakastunniste- ja ohjausosan uutta kirjausta varten.
 * Palauttaa { error } tai { client: {mode, hash, id}, services: [id], updates: [{id, status}] }.
 */
async function prepareClientPart(body, type, sensitiveHit, projectId) {
  const out = { client: null, services: [], updates: [] };
  if (type !== 'yksilo') return out;
  const mode = body.client_mode || 'none';
  if (!['none', 'existing', 'new'].includes(mode)) return { error: 'Virheellinen asiakastunnisteen valinta.' };
  if (mode !== 'none') {
    if (!ENABLED) return { error: 'Asiakastunnisteet eivät ole käytössä (PSEUDONYM_KEY puuttuu palvelimelta).' };
    const ref = String(body.client_ref || '');
    const err = validateRef(ref, sensitiveHit); if (err) return { error: err };
    const hash = hashRef(projectId, ref);
    const existing = await findClient(projectId, ref);
    if (mode === 'existing' && !existing) return { error: 'Asiakastunnistetta ei löydy tästä hankkeesta. Tarkista kirjoitusasu tai valitse ”Uusi asiakas”.' };
    if (mode === 'new' && existing) return { error: 'Tunniste on jo toisen asiakkaan käytössä tässä hankkeessa. Valitse toinen tunniste tai luo satunnainen tunnus.' };
    out.client = { mode, hash, projectId, id: existing ? existing.id : null, generated: !!body.client_generated };
  }
  const services = Array.isArray(body.referrals) ? [...new Set(body.referrals.map(Number))] : [];
  if (services.length) {
    const ok = await db.all(`SELECT id FROM referral_services WHERE active = 1 AND id IN (${services.map(() => '?').join(',')})`, ...services);
    if (ok.length !== services.length) return { error: 'Virheellinen ohjauspalvelu.' };
    out.services = services;
  }
  const updates = Array.isArray(body.referral_updates) ? body.referral_updates : [];
  if (updates.length) {
    if (!out.client || !out.client.id) return { error: 'Ohjauksen tilan voi päivittää vain palaavalle asiakkaalle.' };
    for (const u of updates) {
      if (!['toteutui', 'ei_toteutunut'].includes(u.status)) continue;
      const r = await db.get("SELECT id FROM referrals WHERE id = ? AND client_id = ? AND status = 'avoin'", Number(u.id), out.client.id);
      if (!r) return { error: 'Ohjausta ei löydy tai sen tila on jo päivitetty.' };
      out.updates.push({ id: r.id, status: u.status });
    }
  }
  return out;
}

/** Tallentaa asiakas- ja ohjausosan. Kutsutaan kirjauksen tallennustransaktion sisällä. */
async function applyClientPart(part, { encounterId, encounterDate, userId, isTest = 0 }) {
  let clientId = null;
  if (part.client) {
    clientId = part.client.id;
    if (part.client.mode === 'new') {
      clientId = await insertId('INSERT INTO clients (project_id, ref_hash, generated, created_by, is_test) VALUES (?, ?, ?, ?, ?)',
        part.client.projectId, part.client.hash, part.client.generated ? 1 : 0, userId, isTest);
    }
    await db.run('UPDATE encounters SET client_id = ? WHERE id = ?', clientId, encounterId);
  }
  for (const sid of part.services) {
    await db.run('INSERT INTO referrals (encounter_id, client_id, service_id, referred_on, status) VALUES (?, ?, ?, ?, ?)',
      encounterId, clientId, sid, encounterDate, clientId ? 'avoin' : 'ei_seurattavissa');
  }
  for (const u of part.updates) {
    await db.run("UPDATE referrals SET status = ?, status_on = ?, status_encounter_id = ?, status_by = ? WHERE id = ? AND status = 'avoin'",
      u.status, encounterDate, encounterId, userId, u.id);
  }
  return clientId;
}

// Säilytysaika: linkitys katkaistaan asiakkailta, joita ei ole kohdattu N kuukauteen.
async function applyRetention() {
  if (!(RETENTION_MONTHS > 0)) return 0;
  const stale = (await db.all(`SELECT c.id FROM clients c
    WHERE COALESCE((SELECT MAX(e.encounter_date) FROM encounters e WHERE e.client_id = c.id), c.created_at::date)
          < current_date - make_interval(months => ?::int)`, RETENTION_MONTHS)).map(r => r.id);
  if (!stale.length) return 0;
  await db.tx(async () => {
    await db.run('UPDATE encounters SET client_id = NULL WHERE client_id = ANY(?::int[])', stale);
    await db.run("UPDATE referrals SET client_id = NULL, status = CASE status WHEN 'avoin' THEN 'ei_seurattavissa' ELSE status END WHERE client_id = ANY(?::int[])", stale);
    await db.run('DELETE FROM clients WHERE id = ANY(?::int[])', stale);
    await audit(null, 'client_retention', 'client', null, { unlinked: stale.length, months: RETENTION_MONTHS });
  });
  return stale.length;
}

// --- Asiakaspolkujen koostetiedot ---------------------------------------------
// Kaikki luvut ovat koosteita. Pienet asiakasmäärät (1–2) piilotetaan
// ristiintaulukoinnissa, jotta yksittäistä asiakasta ei voi päätellä.
async function pathStats({ from, to, projectIds, projectId }) {
  const ph = projectIds.map(() => '?').join(',') || 'NULL';
  const encWhere = [`e.deleted_at IS NULL`, `e.project_id IN (${ph})`];
  const p = [...projectIds];
  if (from) { encWhere.push('e.encounter_date >= ?'); p.push(from); }
  if (to) { encWhere.push('e.encounter_date <= ?'); p.push(to); }
  if (projectId) { encWhere.push('e.project_id = ?'); p.push(projectId); }
  const W = encWhere.join(' AND ');

  const coverage = await db.get(`SELECT COUNT(*) AS yksilo_rows, COUNT(e.client_id) AS with_client, COUNT(DISTINCT e.client_id) AS clients
                                 FROM encounters e WHERE ${W} AND e.kind = 'yksilo'`, ...p);

  // Asiakkaat, jotka kohdattiin rajauksella; heidän historiansa hankkeessa loppupäivään asti.
  // Asiakas kuuluu aina yhteen hankkeeseen, joten hankkeiden välisiä lukuja ei ole.
  const toDate = to || '9999-12-31';
  const lifetime = await db.all(`
    WITH c AS (SELECT DISTINCT e.client_id AS id FROM encounters e WHERE ${W} AND e.client_id IS NOT NULL)
    SELECT c.id, COUNT(x.id) AS visits, MIN(x.encounter_date) AS first_date
    FROM c JOIN encounters x ON x.client_id = c.id AND x.deleted_at IS NULL AND x.encounter_date <= ?
    GROUP BY c.id`, ...p, toDate);

  const newClients = lifetime.filter(c => !from || c.first_date >= from).length;
  const returning = lifetime.filter(c => c.visits >= 2).length;
  const buckets = [['1 kohtaaminen', 1, 1], ['2–3', 2, 3], ['4–9', 4, 9], ['10 tai enemmän', 10, Infinity]]
    .map(([label, lo, hi]) => ({ label, value: lifetime.filter(c => c.visits >= lo && c.visits <= hi).length }));

  // Ohjaukset, jotka tehtiin rajauksen kirjauksissa
  const refs = await db.all(`SELECT r.status, rs.name AS service, rs.id AS service_id, r.status_on - r.referred_on AS days
                             FROM referrals r JOIN encounters e ON e.id = r.encounter_id JOIN referral_services rs ON rs.id = r.service_id
                             WHERE ${W}`, ...p);
  const byStatus = { avoin: 0, toteutui: 0, ei_toteutunut: 0, ei_seurattavissa: 0 };
  const bySvc = new Map();
  for (const r of refs) {
    byStatus[r.status]++;
    const s = bySvc.get(r.service) || { service: r.service, total: 0, avoin: 0, toteutui: 0, ei_toteutunut: 0, ei_seurattavissa: 0 };
    s.total++; s[r.status]++; bySvc.set(r.service, s);
  }
  const doneDays = refs.filter(r => r.status === 'toteutui' && r.days != null).map(r => r.days).sort((a, b) => a - b);
  const median = doneDays.length ? doneDays[Math.floor((doneDays.length - 1) / 2)] : null;
  const rate = (s) => (s.toteutui + s.ei_toteutunut ? s.toteutui / (s.toteutui + s.ei_toteutunut) : null);
  const services = [...bySvc.values()].map(s => ({ ...s, rate: rate(s) })).sort((a, b) => b.total - a.total);

  return {
    enabled: ENABLED,
    coverage: { ...coverage, share: coverage.yksilo_rows ? coverage.with_client / coverage.yksilo_rows : null },
    clients: { total: lifetime.length, new: newClients, returning },
    visitBuckets: buckets,
    referrals: { total: refs.length, ...byStatus, rate: rate(byStatus), median_days: median },
    services,
  };
}

module.exports = {
  ENABLED, RETENTION_MONTHS, normalize, hashRef, validateRef, findClient, generateUniqueCode, clientSummary,
  prepareClientPart, applyClientPart, applyRetention, pathStats,
};
