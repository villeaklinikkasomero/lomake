'use strict';
// Virheloki testausta ja ylläpitoa varten (Hallinta → Virheloki).
// Tallennetaan palvelinvirheet, hylätyt tallennukset (esim. validointi), selaimen JavaScript-virheet,
// yhteyskatkot sekä käyttäjien "Ilmoita ongelmasta" -viestit. Lokiin EI tallenneta lomakkeen sisältöä;
// viesteistä poistetaan henkilötunnukselta, sähköpostilta ja puhelinnumerolta näyttävät merkkijonot.

const crypto = require('crypto');
const { db } = require('./db');

// Taulu: migrations/002_roolit_ja_virheloki.sql

const KINDS = ['server_error', 'rejected', 'js_error', 'network', 'feedback'];
const RETENTION_DAYS = Number(process.env.ERROR_LOG_RETENTION_DAYS || 90);

const newCode = () => crypto.randomBytes(3).toString('hex').toUpperCase();

// Tunnistetietojen poisto vapaasta tekstistä
function redact(text, max = 500) {
  if (text == null) return null;
  return String(text)
    .replace(/\b\d{6}[-+A-FU-Y]\d{3}[0-9A-FHJ-NPR-Y]\b/gi, '[htun]')
    .replace(/[^\s@]+@[^\s@]+\.[a-z]{2,}/gi, '[email]')
    .replace(/(\+358|\b0)\s?\d{1,3}[\s-]?\d{3}[\s-]?\d{3,4}\b/g, '[puh]')
    .slice(0, max);
}

// Laite ja selain lyhyesti (koko user agent -merkkijonoa ei tallenneta)
function deviceOf(ua) {
  ua = String(ua || '');
  const os = /iPhone/.test(ua) ? 'iPhone' : /iPad/.test(ua) ? 'iPad' : /Android/.test(ua) ? 'Android' : /Windows/.test(ua) ? 'Windows'
    : /Mac OS X/.test(ua) ? 'Mac' : /Linux/.test(ua) ? 'Linux' : 'muu';
  const br = /Edg\//.test(ua) ? 'Edge' : /CriOS|Chrome\//.test(ua) ? 'Chrome' : /FxiOS|Firefox\//.test(ua) ? 'Firefox' : /Safari\//.test(ua) ? 'Safari' : 'muu';
  return `${os} · ${br}`;
}

// Palauttaa virhekoodin heti; kirjoitus tehdään taustalla transaktion ulkopuolella (pool),
// jotta epäonnistuneen pyynnön transaktion peruminen ei poista lokiriviä eikä lokivirhe kaada pyyntöä.
function log(e) {
  const code = e.code || newCode();
  db.pool.query(`INSERT INTO error_log (code, source, kind, status, method, path, view, message, detail, user_id, role, device, build)
                 VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)`, [
    code, e.source, KINDS.includes(e.kind) ? e.kind : 'js_error', e.status ?? null, e.method || null,
    e.path ? String(e.path).split('?')[0].slice(0, 200) : null, e.view ? String(e.view).split('?')[0].slice(0, 100) : null,
    redact(e.message), redact(e.detail, 2000), e.user_id ?? null, e.role || null, e.device || null, e.build || null,
  ]).catch(err => console.error('Virhelokiin kirjoitus epäonnistui:', err.message));
  return code;
}

function list({ days = 7, kind = null, limit = 500 } = {}) {
  const where = ["l.at >= timezone('utc', now()) - make_interval(days => ?)"]; const params = [Math.max(1, Math.min(365, Number(days) || 7))];
  if (kind && KINDS.includes(kind)) { where.push('l.kind = ?'); params.push(kind); }
  return db.all(`SELECT l.*, u.name AS user_name FROM error_log l LEFT JOIN users u ON u.id = l.user_id
    WHERE ${where.join(' AND ')} ORDER BY l.id DESC LIMIT ?`, ...params, Math.min(2000, Number(limit) || 500));
}

const purge = async () => (await db.run("DELETE FROM error_log WHERE at < timezone('utc', now()) - make_interval(days => ?)", RETENTION_DAYS)).changes;
const clear = async () => (await db.run('DELETE FROM error_log')).changes;

module.exports = { log, list, purge, clear, redact, deviceOf, newCode, KINDS };
