'use strict';
// Skeemamigraatiot: migrations/*.sql ajetaan nimen mukaisessa järjestyksessä, kukin omassa
// transaktiossaan, ja ajetut kirjataan tauluun schema_migrations. Advisory lock estää
// samanaikaiset ajot, jos sovelluksesta käynnistyy useampi instanssi yhtä aikaa.
// Ajettua migraatiota ei muuteta: muutokset tehdään aina uutena tiedostona (002_..., 003_...).

const fs = require('fs');
const path = require('path');

const DIR = path.join(__dirname, '..', 'migrations');
const LOCK_KEY = 'kohtaamiset:migrate';

async function migrate(pool, { afterMigrations } = {}) {
  const client = await pool.connect();
  try {
    await client.query('SELECT pg_advisory_lock(hashtext($1))', [LOCK_KEY]);
    await client.query(`CREATE TABLE IF NOT EXISTS schema_migrations (
      version    text PRIMARY KEY,
      applied_at timestamp(0) NOT NULL DEFAULT timezone('utc', now()))`);
    const done = new Set((await client.query('SELECT version FROM schema_migrations')).rows.map(r => r.version));
    const files = fs.readdirSync(DIR).filter(f => /^\d+_.+\.sql$/.test(f)).sort();
    const applied = [];
    for (const file of files) {
      if (done.has(file)) continue;
      try {
        await client.query('BEGIN');
        await client.query(fs.readFileSync(path.join(DIR, file), 'utf8'));
        await client.query('INSERT INTO schema_migrations (version) VALUES ($1)', [file]);
        await client.query('COMMIT');
        applied.push(file);
      } catch (e) {
        await client.query('ROLLBACK').catch(() => {});
        throw new Error(`Migraatio ${file} epäonnistui: ${e.message}`);
      }
    }
    // Perusdata lisätään saman lukon alla, jottei kaksi instanssia lisää sitä yhtä aikaa
    if (afterMigrations) await afterMigrations();
    return applied;
  } finally {
    await client.query('SELECT pg_advisory_unlock(hashtext($1))', [LOCK_KEY]).catch(() => {});
    client.release();
  }
}

module.exports = { migrate };
