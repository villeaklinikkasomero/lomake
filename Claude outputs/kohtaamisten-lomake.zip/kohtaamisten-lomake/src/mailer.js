'use strict';
// Sähköpostin lähetys Mailgunin HTTP-rajapinnalla. Ilman MAILGUN_API_KEY- ja MAILGUN_DOMAIN-asetuksia
// lähetys ohitetaan hiljaisesti. Viesteihin ei laiteta asiakastietoja eikä salasanoja.
const KEY = process.env.MAILGUN_API_KEY;
const DOMAIN = process.env.MAILGUN_DOMAIN;
const FROM = process.env.MAILGUN_FROM || (DOMAIN ? `Kohtaamisten raportointi <noreply@${DOMAIN}>` : null);
// Oletuksena EU-alue (data pysyy EU:ssa); 'us' vain jos Mailgun-domain on luotu US-alueelle
const BASE = process.env.MAILGUN_API_URL // vain testeihin tai omaan välityspalvelimeen
  || (process.env.MAILGUN_REGION === 'us' ? 'https://api.mailgun.net' : 'https://api.eu.mailgun.net');
const APP_URL = (process.env.APP_URL || '').replace(/\/+$/, '');
const APP_NAME = 'Kohtaamisten raportointi';
// Kehityskäyttö: MAIL_TRANSPORT=console tulostaa viestit konsoliin Mailgunin sijaan.
// Ei toimi tuotannossa, jottei salasanalinkkejä päädy palvelimen lokeihin.
const CONSOLE = process.env.MAIL_TRANSPORT === 'console' && process.env.NODE_ENV !== 'production';

const enabled = () => CONSOLE || Boolean(KEY && DOMAIN);
// Linkkejä sisältävät viestit vaativat julkisen osoitteen (ei johdeta pyynnön Host-otsakkeesta)
const linksEnabled = () => enabled() && Boolean(APP_URL);

async function send({ to, subject, text }) {
  if (!enabled()) return false;
  if (CONSOLE) {
    console.log(`\n----- Sähköposti (MAIL_TRANSPORT=console) -----\nVastaanottaja: ${to}\nAihe: ${subject}\n\n${text}\n-----------------------------------------------\n`);
    return true;
  }
  // o:tracking=no: ei avaus- eikä linkkiseurantaa
  const body = new URLSearchParams({ from: FROM, to, subject, text, 'o:tracking': 'no' });
  const res = await fetch(`${BASE}/v3/${encodeURIComponent(DOMAIN)}/messages`, {
    method: 'POST',
    headers: { Authorization: 'Basic ' + Buffer.from(`api:${KEY}`).toString('base64') },
    body,
    signal: AbortSignal.timeout(10000),
  });
  if (!res.ok) throw new Error(`Mailgun ${res.status}: ${(await res.text()).slice(0, 200)}`);
  return true;
}

// Lähetys taustalla: epäonnistuminen kirjataan lokiin, mutta se ei kaada pyyntöä.
function sendLater(msg) {
  send(msg).catch(e => console.error('Sähköpostin lähetys epäonnistui:', e.message));
}

const footer = () => [
  '',
  APP_URL ? `Kirjaudu: ${APP_URL}` : null,
  '',
  `Tämä on automaattinen viesti palvelusta ${APP_NAME}. Älä vastaa tähän viestiin.`,
].filter(l => l !== null).join('\n');

function notifyAccountCreated(user) {
  const how = user.auth_method === 'entra'
    ? 'Kirjaudu säätiön Microsoft-tunnuksellasi painikkeella "Kirjaudu Microsoft-tunnuksella".'
    : 'Saat väliaikaisen salasanan ylläpitäjältä. Ensimmäisellä kirjautumisella vaihdat salasanan ja otat käyttöön todennussovelluksen (esim. Microsoft Authenticator).';
  sendLater({
    to: user.email,
    subject: `Sinulle on luotu tunnus: ${APP_NAME}`,
    text: `Hei ${user.name},\n\nsinulle on luotu tunnus palveluun ${APP_NAME}.\n\n${how}\n${footer()}`,
  });
}

function notifyPasswordReset(user) {
  sendLater({
    to: user.email,
    subject: `Salasanasi on nollattu: ${APP_NAME}`,
    text: `Hei ${user.name},\n\nylläpitäjä on nollannut salasanasi palvelussa ${APP_NAME}. Saat uuden väliaikaisen salasanan ylläpitäjältä.\n\nJos et pyytänyt nollausta, ilmoita asiasta ylläpitäjälle.\n${footer()}`,
  });
}

function notifyMfaReset(user) {
  sendLater({
    to: user.email,
    subject: `Todennussovellus on nollattu: ${APP_NAME}`,
    text: `Hei ${user.name},\n\nylläpitäjä on nollannut todennussovelluksesi palvelussa ${APP_NAME}. Seuraavalla kirjautumisella otat todennussovelluksen uudelleen käyttöön lukemalla QR-koodin.\n\nJos et pyytänyt nollausta, ilmoita asiasta ylläpitäjälle.\n${footer()}`,
  });
}

function sendPasswordResetLink(user, token, minutes) {
  sendLater({
    to: user.email,
    subject: `Salasanan vaihto: ${APP_NAME}`,
    text: `Hei ${user.name},\n\nsalasanan vaihtoa on pyydetty tunnuksellesi palvelussa ${APP_NAME}. Aseta uusi salasana tästä linkistä:\n\n${APP_URL}/#/uusi-salasana?t=${token}\n\nLinkki on voimassa ${minutes} minuuttia ja toimii vain kerran. Kirjautuessa tarvitset edelleen todennussovelluksen koodin.\n\nJos et pyytänyt vaihtoa, voit jättää tämän viestin huomiotta. Salasanasi ei muutu.\n\nTämä on automaattinen viesti palvelusta ${APP_NAME}. Älä vastaa tähän viestiin.`,
  });
}

function notifyPasswordChanged(user) {
  sendLater({
    to: user.email,
    subject: `Salasanasi on vaihdettu: ${APP_NAME}`,
    text: `Hei ${user.name},\n\nsalasanasi on vaihdettu palvelussa ${APP_NAME} sähköpostilinkin kautta.\n\nJos et tehnyt vaihtoa itse, ilmoita asiasta heti ylläpitäjälle.\n${footer()}`,
  });
}

module.exports = { enabled, linksEnabled, send, sendLater, notifyAccountCreated, notifyPasswordReset, notifyMfaReset, sendPasswordResetLink, notifyPasswordChanged };
