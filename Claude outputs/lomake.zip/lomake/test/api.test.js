'use strict';
// Rooli- ja toimintotestit: node --test test/
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const os = require('os');
const path = require('path');
const fs = require('fs');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'kohtaamiset-'));
process.env.DB_PATH = path.join(tmp, 'test.db');
const app = require('../src/server');
const { db, ensureAdmin } = require('../src/db');
const bcrypt = require('bcryptjs');

let server, base;
before(async () => {
  ensureAdmin();
  // Hankekohtaiset 2027-kysymykset eivät ole pakollisia yleistesteissä (omat testinsä alla)
  db.prepare('UPDATE questions SET required = 0 WHERE project_id IS NOT NULL').run();
  db.prepare("UPDATE users SET email='admin@t.fi', password_hash=?, must_change_password=0 WHERE role='admin'").run(bcrypt.hashSync('Admin-salasana-1', 4));
  server = app.listen(0); await new Promise(r => server.once('listening', r));
  base = `http://127.0.0.1:${server.address().port}`;
});
after(() => { server.close(); });

function client() {
  let cookie = '';
  return async (method, p, body, raw) => {
    const res = await fetch(base + '/api' + p, { method, headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'kohtaamiset', cookie },
      body: body ? JSON.stringify(body) : undefined });
    const sc = res.headers.get('set-cookie'); if (sc) cookie = sc.split(';')[0];
    if (raw) return res;
    let data = null; try { data = await res.json(); } catch {}
    return { status: res.status, data };
  };
}
async function login(email, pw) { const c = client(); const r = await c('POST', '/login', { email, password: pw }); assert.equal(r.status, 200, JSON.stringify(r.data)); return c; }

const P = () => Object.fromEntries(db.prepare('SELECT code, id FROM projects').all().map(r => [r.code, r.id]));
const today = new Date().toISOString().slice(0, 10);
const basePayload = (pid, extra = {}) => ({ project_id: pid, encounter_date: today,
  encounter_type: 'yksilo', pseudonym: 'Kettu', answers: { tyontekijan_arvio: '4', ika: '18–29 vuotta', tyontekijan_huomiot: 'Hyvä keskustelu.' }, ...extra });

const users = {};
test('admin luo käyttäjät ja väliaikainen salasana pakottaa vaihdon', async () => {
  const a = await login('admin@t.fi', 'Admin-salasana-1');
  const p = P();
  const mk = async (email, role, projects) => {
    const r = await a('POST', '/users', { name: email.split('@')[0], email, role, project_ids: projects });
    assert.equal(r.status, 201, JSON.stringify(r.data));
    const c = await login(email, r.data.temporaryPassword);
    assert.equal((await c('GET', '/form')).status, 403);            // salasana vaihdettava ensin
    assert.equal((await c('POST', '/me/password', { current: r.data.temporaryPassword, next: 'Uusi-salasana-123' })).status, 200);
    users[role] = await login(email, 'Uusi-salasana-123');
  };
  await mk('tv@t.fi', 'tiimivetaja', [p.KATUKLINIKKA, p.AK21]);
  await mk('ht@t.fi', 'hanketyontekija', [p.KATUKLINIKKA]);
  await mk('tt@t.fi', 'tuntityontekija', [p.KATUKLINIKKA]);
  users.admin = a;
});

test('kirjaus: validointi, hankerajaus ja tunnistetietojen esto', async () => {
  const p = P(); const ht = users.hanketyontekija;
  let r = await ht('POST', '/encounters', basePayload(p.KATUKLINIKKA));
  assert.equal(r.status, 201, JSON.stringify(r.data));
  r = await ht('POST', '/encounters', basePayload(p.JALMA));
  assert.equal(r.status, 400); assert.match(r.data.error, /oikeutta/);
  r = await ht('POST', '/encounters', basePayload(p.KATUKLINIKKA, { answers: { tyontekijan_arvio: '3', tyontekijan_huomiot: 'Hetu 010190-123A' } }));
  assert.equal(r.status, 400); assert.match(r.data.error, /henkilötunnu/);
  r = await ht('POST', '/encounters', basePayload(p.KATUKLINIKKA, { answers: {} }));
  assert.equal(r.status, 400); assert.match(r.data.error, /Työntekijän arvio/);
  r = await ht('POST', '/encounters', basePayload(p.KATUKLINIKKA, { encounter_date: '2999-01-01' }));
  assert.equal(r.status, 400);
  r = await ht('POST', '/encounters', basePayload(p.KATUKLINIKKA, { encounter_type: 'ryhma', encounter_count: 0 }));
  assert.equal(r.status, 400);
});

test('ryhmäkirjaus ja hankekohtainen kysymys', async () => {
  const p = P(); const tv = users.tiimivetaja;
  const r = await tv('POST', '/encounters', basePayload(p.AK21, { encounter_type: 'ryhma', encounter_count: 25, person_count: 8, pseudonym: 'ei tallennu',
    answers: { tyontekijan_arvio: '5', ika: '18–29 vuotta', ak21_toimintamuoto_2027: 'Selvä suunta -ryhmä' } }));
  assert.equal(r.status, 201, JSON.stringify(r.data));
  const d = await tv('GET', '/encounters/' + r.data.id);
  assert.equal(d.data.encounter.pseudonym, undefined);   // selväkielistä nimimerkkiä ei palauteta
  assert.equal(d.data.encounter.client_linked, false);
  assert.equal(d.data.encounter.answers.ak21_toimintamuoto_2027, 'Selvä suunta -ryhmä');
  assert.equal(d.data.encounter.answers.ika, undefined);     // ikä koskee vain yksilökohtaamisia
});

test('tuntityöntekijä: kirjaus kyllä, selaus ja vienti ei', async () => {
  const p = P(); const tt = users.tuntityontekija;
  const r = await tt('POST', '/encounters', basePayload(p.KATUKLINIKKA, { recorder_role: 'A-klinikkasäätiön asiantuntija tai ohjaaja' }));
  assert.equal(r.status, 201);
  assert.equal((await tt('GET', '/encounters')).status, 403);
  assert.equal((await tt('GET', '/encounters/' + r.data.id)).status, 404);
  assert.equal((await tt('GET', `/export?from=2020-01-01&to=${today}`)).status, 403);
  assert.equal((await tt('GET', '/users')).status, 403);
});

test('hanketyöntekijä näkee ja korjaa vain omat, ei voi poistaa/viedä', async () => {
  const ht = users.hanketyontekija;
  const list = await ht('GET', '/encounters');
  assert.equal(list.status, 200);
  assert.ok(list.data.rows.length >= 1);
  assert.ok(list.data.rows.every(r => r.created_by_name === 'ht'));
  const id = list.data.rows[0].id;
  assert.ok(list.data.rows[0].canEdit);
  const upd = await ht('PUT', '/encounters/' + id, basePayload(P().KATUKLINIKKA));
  assert.equal(upd.status, 200, JSON.stringify(upd.data));
  const other = db.prepare("SELECT e.id FROM encounters e JOIN users u ON u.id = e.created_by WHERE u.email <> 'ht@t.fi' LIMIT 1").get();
  if (other) assert.equal((await ht('PUT', '/encounters/' + other.id, basePayload(P().KATUKLINIKKA))).status, 403);
  assert.equal((await ht('DELETE', '/encounters/' + id)).status, 403);
  assert.equal((await ht('GET', `/export?from=2020-01-01&to=${today}`)).status, 403);
});

test('kirjaajan rooli tulee profiilista eikä muutu korjauksessa', async () => {
  const TT = 'Tuntityöntekijä tai ulkopuolinen asiantuntija, ohjaaja, avustaja tai neuvontapalvelun vastaaja';
  const rows = db.prepare(`SELECT e.id, e.recorder_role FROM encounters e JOIN users u ON u.id = e.created_by WHERE u.email = 'tt@t.fi'`).all();
  assert.ok(rows.length && rows.every(r => r.recorder_role === TT), 'lomakkeelta lähetetty rooli ohitetaan');
  const upd = await users.tiimivetaja('PUT', '/encounters/' + rows[0].id, basePayload(P().KATUKLINIKKA));
  assert.equal(upd.status, 200, JSON.stringify(upd.data));
  assert.equal(db.prepare('SELECT recorder_role FROM encounters WHERE id = ?').get(rows[0].id).recorder_role, TT);
  // Kirjaajan rooli johdetaan aina käyttöoikeusroolista, lähetetty arvo ohitetaan
  const SAATIO = 'A-klinikkasäätiön asiantuntija tai ohjaaja';
  const r = await users.admin('POST', '/users', { name: 'Avustaja', email: 'v@t.fi', role: 'tuntityontekija', recorder_role: SAATIO, project_ids: [] });
  assert.equal(r.status, 201);
  assert.equal(db.prepare("SELECT recorder_role FROM users WHERE email='v@t.fi'").get().recorder_role, TT);
  const vid = db.prepare("SELECT id FROM users WHERE email='v@t.fi'").get().id;
  await users.admin('PUT', '/users/' + vid, { name: 'Avustaja', email: 'v@t.fi', role: 'tiimivetaja', project_ids: [] });
  assert.equal(db.prepare('SELECT recorder_role FROM users WHERE id = ?').get(vid).recorder_role, SAATIO);
});

test('tiiminvetäjä näkee hankkeidensa kaikki, korjaa ja poistaa', async () => {
  const tv = users.tiimivetaja;
  const list = await tv('GET', '/encounters');
  const names = new Set(list.data.rows.map(r => r.created_by_name));
  assert.ok(names.has('ht') && names.has('tt') && names.has('tv'));
  const target = list.data.rows.find(r => r.created_by_name === 'ht');
  const upd = await tv('PUT', '/encounters/' + target.id, basePayload(P().KATUKLINIKKA, { answers: { tyontekijan_arvio: '2' } }));
  assert.equal(upd.status, 200, JSON.stringify(upd.data));
  const d = await tv('GET', '/encounters/' + target.id);
  assert.equal(d.data.encounter.answers.tyontekijan_arvio, '2');
  // Ei pääsyä toisen hankkeen vientiin
  assert.equal((await tv('GET', `/export?from=2020-01-01&to=${today}&projects=${P().JALMA}`)).status, 403);
  assert.equal((await tv('GET', '/questions')).status, 403);
});

test('Excel-vienti: rivit, sarakkeet, ei nimimerkkejä', async () => {
  const ExcelJS = require('exceljs');
  const res = await users.tiimivetaja('GET', `/export?from=2020-01-01&to=${today}`, null, true);
  assert.equal(res.status, 200);
  const wb = new ExcelJS.Workbook(); await wb.xlsx.load(Buffer.from(await res.arrayBuffer()));
  const ws = wb.getWorksheet('Kohtaamiset');
  const headers = ws.getRow(1).values.slice(1);
  assert.ok(headers.includes('Kohtaamisen ajankohta') && headers.includes('Tallennettu') && headers.includes('Tunniste'));
  assert.ok(headers.some(h => /toimintamuodossa/.test(h)));
  assert.ok(!headers.some(h => /nimimerk/i.test(h)));
  const total = db.prepare('SELECT COUNT(*) n FROM encounters WHERE deleted_at IS NULL').get().n;
  assert.equal(ws.rowCount - 1, total);
  let found = false; ws.eachRow((row) => { row.values.forEach(v => { if (v === 'Kettu') found = true; }); });
  assert.equal(found, false, 'nimimerkki ei saa päätyä vientiin');
});

test('admin: kysymyksen lisäys ja käytöstä poisto säilyttää vanhat vastaukset', async () => {
  const a = users.admin; const p = P();
  let r = await a('POST', '/questions', { key: 'katu_tarjottu_tuki', project_id: p.KATUKLINIKKA, label: 'Tarjottu tuki', type: 'multichoice',
    options: ['Neuvonta', 'Välineet', 'Ohjaus palveluihin'], applies_to: 'kaikki', required: false });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  const qid = r.data.id;
  r = await users.hanketyontekija('POST', '/encounters', basePayload(p.KATUKLINIKKA, { answers: { tyontekijan_arvio: '4', katu_tarjottu_tuki: ['Neuvonta', 'Välineet'] } }));
  assert.equal(r.status, 201);
  const encId = r.data.id;
  r = await a('PUT', '/questions/' + qid, { label: 'Tarjottu tuki', type: 'text', applies_to: 'kaikki', options: [] });
  assert.equal(r.status, 400);  // tyypin muutos estetty
  r = await a('PUT', '/questions/' + qid, { label: 'Tarjottu tuki', type: 'multichoice', applies_to: 'kaikki', options: ['Neuvonta', 'Välineet', 'Ohjaus palveluihin'], active: false });
  assert.equal(r.status, 200);
  const d = await a('GET', '/encounters/' + encId);
  assert.deepEqual(d.data.encounter.answers.katu_tarjottu_tuki, ['Neuvonta', 'Välineet']);
  // Tuntityöntekijän lomakkeella kysymystä ei enää näy
  const f = await users.tuntityontekija('GET', '/form');
  assert.ok(!f.data.questions.some(q => q.key === 'katu_tarjottu_tuki'));
});

test('suljettu tunnus ei pääse sisään ja CSRF-otsake vaaditaan', async () => {
  const a = users.admin;
  const u = db.prepare("SELECT id FROM users WHERE email='tt@t.fi'").get();
  const r = await a('PUT', '/users/' + u.id, { name: 'tt', email: 'tt@t.fi', role: 'tuntityontekija', project_ids: [], active: false });
  assert.equal(r.status, 200);
  assert.equal((await users.tuntityontekija('GET', '/form')).status, 401);
  const c = client(); const res = await c('POST', '/login', { email: 'tt@t.fi', password: 'Uusi-salasana-123' });
  assert.equal(res.status, 401);
  const noHeader = await fetch(base + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
  assert.equal(noHeader.status, 403);
});

test('testidata: vähintään 30 erilaista kirjausta, kaikki hankkeet, poisto koskee vain testidataa', async () => {
  const a = users.admin;
  const realBefore = db.prepare('SELECT COUNT(*) n FROM encounters WHERE is_test = 0').get().n;
  const r = await a('POST', '/admin/demo-data', { count: 40 });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  assert.equal(r.data.created, 40);
  const rows = db.prepare(`SELECT e.*, (SELECT group_concat(question_id || '=' || value, '|') FROM encounter_answers WHERE encounter_id = e.id) ans
                           FROM encounters e WHERE is_test = 1`).all();
  const distinct = new Set(rows.map(e => [e.project_id, e.encounter_date, e.encounter_type, e.encounter_count, e.person_count, e.pseudonym, e.recorder_role, e.ans].join('#')));
  assert.ok(distinct.size >= 30, `erilaisia ${distinct.size}`);
  const activeProjects = db.prepare('SELECT COUNT(*) n FROM projects WHERE active = 1').get().n;
  assert.equal(new Set(rows.map(e => e.project_id)).size, activeProjects);
  assert.ok(rows.some(e => e.encounter_type === 'ryhma') && rows.some(e => e.encounter_type === 'yksilo'));
  assert.ok(new Set(rows.map(e => e.recorder_role)).size >= 2);
  assert.ok(rows.every(e => e.encounter_date <= new Date().toISOString().slice(0, 10)));
  assert.equal((await users.tiimivetaja('POST', '/admin/demo-data', { count: 5 })).status, 403);
  const d = await a('DELETE', '/admin/demo-data');
  assert.equal(d.data.deleted, 40);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM encounters WHERE is_test = 0').get().n, realBefore);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM encounter_answers WHERE encounter_id NOT IN (SELECT id FROM encounters)').get().n, 0);
});

test('työntekijäseuranta: admin kaikki, tiiminvetäjä vain omat hankkeet, muut ei', async () => {
  const p = P();
  // ht kirjaa Katuklinikkaan (tv:n hanke); admin kirjaa Jalmaan (ei tv:n hanke)
  await users.hanketyontekija('POST', '/encounters', basePayload(p.KATUKLINIKKA, { encounter_type: 'ryhma', encounter_count: 12, person_count: 5, answers: { tyontekijan_arvio: '5' } }));
  await users.admin('POST', '/encounters', basePayload(p.JALMA));
  const htId = db.prepare("SELECT id FROM users WHERE email='ht@t.fi'").get().id;
  const adminId = db.prepare("SELECT id FROM users WHERE email='admin@t.fi'").get().id;

  const all = await users.admin('GET', '/staff');
  assert.equal(all.status, 200);
  const htRow = all.data.rows.find(r => r.id === htId);
  assert.ok(htRow && htRow.encounters >= 12 && htRow.worker_rating != null);

  // Jalman tuntityöntekijä (ei tiiminvetäjän eikä hanketyöntekijän hanke)
  const jt = await users.admin('POST', '/users', { name: 'Jalman avustaja', email: 'jt@t.fi', role: 'tuntityontekija', project_ids: [p.JALMA] });
  const jtId = jt.data.id || db.prepare("SELECT id FROM users WHERE email='jt@t.fi'").get().id;
  assert.equal((await users.admin('POST', '/encounters', basePayload(p.JALMA, { performer: String(jtId) }))).status, 201);
  const tvId = db.prepare("SELECT id FROM users WHERE email='tv@t.fi'").get().id;

  // Säätiöläiset näkyvät kaikille kaikkien hankkeiden luvuin; tuntityöntekijät oikeuksien mukaan
  const tv = await users.tiimivetaja('GET', '/staff');
  assert.equal(tv.status, 200);
  const tvAdmin = tv.data.rows.find(r => r.id === adminId);
  assert.ok(tvAdmin && tvAdmin.rows === all.data.rows.find(r => r.id === adminId).rows, 'säätiöläinen näkyy kaikkien hankkeiden luvuin');
  assert.ok(!tv.data.rows.some(r => r.id === jtId), 'toisen hankkeen tuntityöntekijä ei näy');
  assert.ok((await users.admin('GET', '/staff')).data.rows.some(r => r.id === jtId));

  const det = await users.tiimivetaja('GET', `/staff/${htId}`);
  assert.equal(det.status, 200);
  assert.ok(det.data.kpi.encounters >= 12 && det.data.monthly.length >= 1 && det.data.byProject.length >= 1);
  assert.equal(det.data.user.email, undefined);
  assert.equal((await users.tiimivetaja('GET', `/staff/${adminId}`)).status, 200);
  assert.equal((await users.tiimivetaja('GET', `/staff/${jtId}`)).status, 404);

  // Hanketyöntekijä: kaikki säätiöläiset, tuntityöntekijöistä vain yhteismäärät
  const ownStaff = await users.hanketyontekija('GET', '/staff');
  assert.equal(ownStaff.status, 200);
  assert.ok(ownStaff.data.ownOnly);
  const shownRoles = new Set(ownStaff.data.rows.map(r => r.role));
  assert.ok(!shownRoles.has('tuntityontekija'));
  assert.ok([htId, tvId, adminId].every(id => ownStaff.data.rows.some(r => r.id === id)));
  const hourlyRows = db.prepare(`SELECT COUNT(*) n FROM encounters e JOIN users u ON u.id = e.performed_by
    WHERE e.deleted_at IS NULL AND u.role = 'tuntityontekija' AND e.project_id = ?`).get(p.KATUKLINIKKA).n;
  assert.equal(ownStaff.data.others.rows, hourlyRows);
  assert.ok(!JSON.stringify(ownStaff.data.others).includes('name'));
  assert.equal((await users.hanketyontekija('GET', `/staff/${htId}`)).status, 200);
  assert.equal((await users.hanketyontekija('GET', `/staff/${tvId}`)).status, 200);
  const ttId = db.prepare("SELECT id FROM users WHERE email='tt@t.fi'").get().id;
  assert.equal((await users.hanketyontekija('GET', `/staff/${ttId}`)).status, 404);

  // Kirjauslistan kirjaajasuodatin
  const list = await users.tiimivetaja('GET', `/encounters?created_by=${htId}`);
  assert.ok(list.data.rows.length > 0 && list.data.rows.every(r => r.created_by === htId));
  // Hanketyöntekijä ei voi ohittaa omaa rajaustaan
  const own = await users.hanketyontekija('GET', `/encounters?created_by=${adminId}`);
  assert.ok(own.data.rows.every(r => r.created_by === htId));
});

test('testidata jakautuu testityöntekijöille ja poistuu heidän kanssaan', async () => {
  const a = users.admin;
  await a('POST', '/admin/demo-data', { count: 40 });
  const workers = db.prepare('SELECT u.id, COUNT(e.id) n FROM users u JOIN encounters e ON e.created_by = u.id WHERE u.is_test = 1 GROUP BY u.id').all();
  assert.ok(workers.length >= 4, `testityöntekijöitä ${workers.length}`);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM users WHERE is_test = 1 AND active = 1').get().n, 0, 'testitunnukset ovat suljettuja');
  const staff = await a('GET', '/staff');
  assert.ok(staff.data.rows.filter(r => r.is_test && r.rows > 0).length >= 4);
  await a('DELETE', '/admin/demo-data');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM users WHERE is_test = 1').get().n, 0);
});

// ---------------------------------------------------------------------------
// Asiakastunnisteet ja palveluohjaukset
// ---------------------------------------------------------------------------
test('asiakastunniste: hankekohtainen tiiviste, ei hankkeiden välistä linkitystä, ohjaus seurataan hankkeen sisällä', async () => {
  const p = P(); const ht = users.hanketyontekija; const tv = users.tiimivetaja;
  // Palveluohjaukset kuuluvat Asiakaspolut-toimintoon: piilotettuna niitä ei tarjota eikä tallenneta
  require('../src/db').setFeature('paths', false);
  assert.deepEqual((await ht('GET', '/form')).data.referralServices, []);
  const sid = db.prepare('SELECT id FROM referral_services LIMIT 1').get().id;
  let r0 = await ht('POST', '/encounters', basePayload(p.KATUKLINIKKA, { referrals: [sid] }));
  assert.equal(r0.status, 201);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM referrals WHERE encounter_id = ?').get(r0.data.id).n, 0);
  require('../src/db').setFeature('paths', true);
  const svc = (await ht('GET', '/form')).data.referralServices;
  assert.ok(svc.length >= 5);

  // Uusi asiakas Katuklinikalla nimimerkillä, ohjaus päihdepalveluihin
  let r = await ht('POST', '/clients/lookup', { ref: 'Revontuli 77', mode: 'new', project_id: p.KATUKLINIKKA });
  assert.deepEqual(r.data, { available: true });
  r = await ht('POST', '/encounters', basePayload(p.KATUKLINIKKA, { client_mode: 'new', client_ref: 'Revontuli 77', referrals: [svc[0].id] }));
  assert.equal(r.status, 201, JSON.stringify(r.data));
  const firstId = r.data.id;

  // Selväkielistä tunnistetta ei ole missään taulussa
  const dump = JSON.stringify([
    db.prepare('SELECT * FROM clients').all(), db.prepare('SELECT * FROM encounters').all(),
    db.prepare('SELECT * FROM audit_log').all(), db.prepare('SELECT * FROM referrals').all()]).toLowerCase();
  assert.ok(!dump.includes('revontuli'), 'tunniste ei saa näkyä kannassa');
  const katu = db.prepare('SELECT * FROM clients ORDER BY id DESC LIMIT 1').get();
  assert.match(katu.ref_hash, /^[0-9a-f]{64}$/);
  assert.equal(katu.project_id, p.KATUKLINIKKA);

  // Hankkeen sisällä tunniste on yksilöllinen (myös eri kirjoitusasulla)
  r = await ht('POST', '/encounters', basePayload(p.KATUKLINIKKA, { client_mode: 'new', client_ref: 'REVONTULI-77' }));
  assert.equal(r.status, 400); assert.match(r.data.error, /jo toisen asiakkaan/);

  // Toisessa hankkeessa (AK21) sama nimimerkki on eri asiakas: ei löydy, ja sen voi ottaa uudelle asiakkaalle
  r = await tv('POST', '/clients/lookup', { ref: 'revontuli 77', project_id: p.AK21 });
  assert.equal(r.data.found, false);
  r = await tv('POST', '/clients/lookup', { ref: 'revontuli77', mode: 'new', project_id: p.AK21 });
  assert.equal(r.data.available, true);
  r = await tv('POST', '/encounters', basePayload(p.AK21, { client_mode: 'new', client_ref: 'Revontuli 77' }));
  assert.equal(r.status, 201, JSON.stringify(r.data));
  const ak = db.prepare('SELECT * FROM clients ORDER BY id DESC LIMIT 1').get();
  assert.notEqual(ak.id, katu.id);
  assert.notEqual(ak.ref_hash, katu.ref_hash, 'saman nimimerkin tiivisteet eri hankkeissa eivät saa täsmätä');
  // AK21:n haku ei näe Katuklinikan ohjausta
  r = await tv('POST', '/clients/lookup', { ref: 'Revontuli 77', project_id: p.AK21 });
  assert.equal(r.data.summary.open_referrals.length, 0);
  // Hakua ei voi tehdä hankkeeseen, johon ei ole oikeutta
  assert.equal((await ht('POST', '/clients/lookup', { ref: 'Revontuli 77', project_id: p.AK21 })).status, 400);

  // Palaava asiakas samassa hankkeessa: avoin ohjaus näkyy ja sen voi kuitata
  r = await tv('POST', '/clients/lookup', { ref: 'revontuli 77', project_id: p.KATUKLINIKKA });
  assert.equal(r.data.found, true);
  assert.equal(r.data.summary.encounters, 1);
  assert.equal(r.data.summary.open_referrals.length, 1);
  const refId = r.data.summary.open_referrals[0].id;
  r = await tv('POST', '/encounters', basePayload(p.KATUKLINIKKA, { client_mode: 'existing', client_ref: 'Revontuli77',
    referral_updates: [{ id: refId, status: 'toteutui' }] }));
  assert.equal(r.status, 201, JSON.stringify(r.data));
  const ref = db.prepare('SELECT * FROM referrals WHERE id = ?').get(refId);
  assert.equal(ref.status, 'toteutui'); assert.equal(ref.status_encounter_id, r.data.id);
  // Toisen hankkeen asiakkaalle ei voi kuitata tämän hankkeen ohjausta
  const other = db.prepare("INSERT INTO referrals (encounter_id, client_id, service_id, referred_on, status) VALUES (?, ?, ?, ?, 'avoin')").run(firstId, katu.id, svc[1].id, today).lastInsertRowid;
  r = await tv('POST', '/encounters', basePayload(p.AK21, { client_mode: 'existing', client_ref: 'Revontuli 77', referral_updates: [{ id: other, status: 'toteutui' }] }));
  assert.equal(r.status, 400);

  // Kirjauksen tiedot: ei tunnistetta, vain tieto linkityksestä ja ohjaukset
  const det = await tv('GET', '/encounters/' + firstId);
  assert.equal(det.data.encounter.client_linked, true);
  assert.equal(det.data.encounter.client_id, undefined);

  // Satunnaistunnus (hankekohtainen)
  const g = await ht('POST', '/clients/generate', { project_id: p.KATUKLINIKKA });
  assert.match(g.data.code, /^\p{Lu}\p{Ll}+ \p{Lu}\p{Ll}+( \d{1,2})?$/u);
  r = await ht('POST', '/encounters', basePayload(p.KATUKLINIKKA, { client_mode: 'new', client_ref: g.data.code, client_generated: true }));
  assert.equal(r.status, 201);
  // Tunniste ei saa näyttää henkilötunnukselta
  r = await ht('POST', '/clients/lookup', { ref: '010190-123A', mode: 'new', project_id: p.KATUKLINIKKA });
  assert.equal(r.status, 400);
  // Ryhmäkirjaukseen ei liitetä asiakasta
  r = await ht('POST', '/encounters', basePayload(p.KATUKLINIKKA, { encounter_type: 'ryhma', encounter_count: 4, client_mode: 'existing', client_ref: 'Revontuli77' }));
  assert.equal(r.status, 201);
  assert.equal(db.prepare('SELECT client_id FROM encounters WHERE id = ?').get(r.data.id).client_id, null);
});

test('vanhat säätiötasoiset asiakkaat jaetaan hankekohtaisiksi ja päivittyvät haulla', async () => {
  const clients = require('../src/clients');
  const crypto = require('crypto');
  const p = P();
  // Simuloidaan vanhaa riviä: säätiötasoinen tiiviste, merkitty legacy
  const legacy = crypto.createHmac('sha256', 'kehitys-avain-ei-tuotantoon').update('asiakas:' + clients.normalize('Vanha Kettu')).digest('hex');
  const cid = db.prepare('INSERT INTO clients (project_id, ref_hash, legacy) VALUES (?, ?, 1)').run(p.JALMA, legacy).lastInsertRowid;
  const c = clients.findClient(p.JALMA, 'vanha kettu');
  assert.equal(c.id, cid);
  const row = db.prepare('SELECT * FROM clients WHERE id = ?').get(cid);
  assert.equal(row.legacy, 0); assert.equal(row.ref_hash, clients.hashRef(p.JALMA, 'Vanha Kettu'));
  assert.equal(clients.findClient(p.VOLJY, 'vanha kettu'), undefined, 'toisen hankkeen haku ei löydä');
});

test('asiakaspolut: oletuksena piilotettu, admin voi aktivoida', async () => {
  db.prepare("DELETE FROM settings WHERE key = 'feature.paths'").run();
  assert.equal((await users.admin('GET', '/paths')).status, 404);
  const me = await users.tiimivetaja('GET', '/me');
  assert.equal(me.data.features.paths, false);
  assert.equal(me.data.permissions.pathScope, 'none');
  assert.equal((await users.tiimivetaja('PUT', '/features/paths', { enabled: true })).status, 403);
  const r = await users.admin('PUT', '/features/paths', { enabled: true });
  assert.equal(r.status, 200); assert.equal(r.data.enabled, true);
  assert.equal((await users.tiimivetaja('GET', '/me')).data.permissions.pathScope, 'projects');
  const f = await users.admin('GET', '/features');
  assert.ok(f.data.features.find(x => x.key === 'paths').enabled);
});

test('asiakaspolut: koosteet adminille ja tiiminvetäjälle, ei muille; Excel ilman tunnistetta', async () => {
  const s = await users.admin('GET', '/paths');
  assert.equal(s.status, 200, JSON.stringify(s.data));
  assert.ok(s.data.clients.total >= 2);
  assert.ok(s.data.referrals.total >= 1 && s.data.referrals.toteutui >= 1);
  assert.equal((await users.tiimivetaja('GET', '/paths')).status, 200);
  assert.equal((await users.hanketyontekija('GET', '/paths')).status, 403);
  const ExcelJS = require('exceljs');
  const res = await users.admin('GET', `/export?from=2020-01-01&to=${today}`, null, true);
  const wb = new ExcelJS.Workbook(); await wb.xlsx.load(Buffer.from(await res.arrayBuffer()));
  const ws = wb.getWorksheet('Kohtaamiset');
  const headers = ws.getRow(1).values.slice(1);
  assert.ok(headers.includes('Ohjattu palveluun') && headers.includes('Tunnistettu asiakas (yksilö)'));
  let leak = false; ws.eachRow(row => row.values.forEach(v => { if (typeof v === 'string' && /revontuli/i.test(v)) leak = true; }));
  assert.equal(leak, false);
});

test('säilytysaika katkaisee vanhan linkityksen', async () => {
  const clients = require('../src/clients');
  const p = P();
  const r = await users.admin('POST', '/encounters', basePayload(p.JALMA, { encounter_date: '2020-01-02', client_mode: 'new', client_ref: 'Vanha Asiakas', referrals: [1] }));
  assert.equal(r.status, 201, JSON.stringify(r.data));
  assert.ok(clients.findClient(p.JALMA, 'vanha asiakas'));
  clients.applyRetention();
  assert.equal(clients.findClient(p.JALMA, 'vanha asiakas'), undefined);
  assert.equal(db.prepare('SELECT client_id FROM encounters WHERE id = ?').get(r.data.id).client_id, null);
  assert.equal(db.prepare('SELECT status FROM referrals WHERE encounter_id = ?').get(r.data.id).status, 'ei_seurattavissa');
});

test('sijainti valitaan joka kerta; Digialustalla kaupunki ja katu eivät tallennu', async () => {
  const p = P();
  // Digihankkeenkin livekohtaaminen: sijainti ja kaupunki tallentuvat sellaisinaan
  const r = await users.tiimivetaja('POST', '/encounters', basePayload(p.AK21, { answers: { tyontekijan_arvio: '4', sijainti: 'Kadulla tai muulla julkisella paikalla', kaupunki: 'Tampere', kadunnimi: 'Hämeenkatu' } }));
  assert.equal(r.status, 201, JSON.stringify(r.data));
  const d = await users.tiimivetaja('GET', '/encounters/' + r.data.id);
  assert.equal(d.data.encounter.answers.sijainti, 'Kadulla tai muulla julkisella paikalla');
  assert.equal(d.data.encounter.answers.kaupunki, 'Tampere');
  // Ei-digihankkeen digikohtaaminen: kaupunkia ja katua ei tallenneta
  const r2 = await users.tiimivetaja('POST', '/encounters', basePayload(p.KATUKLINIKKA, { answers: { tyontekijan_arvio: '4', sijainti: 'Digialustalla', kaupunki: 'Tampere', kadunnimi: 'Hämeenkatu' } }));
  const d2 = await users.tiimivetaja('GET', '/encounters/' + r2.data.id);
  assert.equal(d2.data.encounter.answers.sijainti, 'Digialustalla');
  assert.equal(d2.data.encounter.answers.kaupunki, undefined);
  assert.equal(d2.data.encounter.answers.kadunnimi, undefined);
  // Sijaintia ei täytetä automaattisesti
  const r3 = await users.tiimivetaja('POST', '/encounters', basePayload(p.AK21));
  assert.equal((await users.tiimivetaja('GET', '/encounters/' + r3.data.id)).data.encounter.answers.sijainti, undefined);
  // Kysymyksen muokkaus ilman asetusta ei nollaa sitä; automaattista arvoa ei enää ole
  const q = db.prepare("SELECT * FROM questions WHERE key = 'kaupunki'").get();
  await users.admin('PUT', '/questions/' + q.id, { label: q.label, help: q.help, type: q.type, applies_to: q.applies_to, options: [] });
  assert.equal(db.prepare("SELECT digital_mode FROM questions WHERE key = 'kaupunki'").get().digital_mode, 'hide');
  const sq = db.prepare("SELECT * FROM questions WHERE key = 'sijainti'").get();
  assert.equal(sq.digital_mode, 'show');
  const bad = await users.admin('PUT', '/questions/' + sq.id, { label: sq.label, type: 'choice', applies_to: 'kaikki', options: JSON.parse(sq.options), digital_mode: 'fixed', digital_value: 'Digialustalla' });
  assert.equal(bad.status, 400);
});

test('asiakkaalta kysytty arvio vain yksilökohtaamisissa', async () => {
  const p = P();
  assert.equal(db.prepare("SELECT applies_to FROM questions WHERE key = 'asiakkaan_arvio'").get().applies_to, 'yksilo');
  const r = await users.tiimivetaja('POST', '/encounters', basePayload(p.KATUKLINIKKA, { encounter_type: 'ryhma', encounter_count: 5, answers: { tyontekijan_arvio: '4', asiakkaan_arvio: '5' } }));
  assert.equal(r.status, 201, JSON.stringify(r.data));
  assert.equal((await users.tiimivetaja('GET', '/encounters/' + r.data.id)).data.encounter.answers.asiakkaan_arvio, undefined);
});

test('kirjaus toisen puolesta: hankkeen käyttäjä tai vapaaehtoinen', async () => {
  const p = P(); const tv = users.tiimivetaja;
  const tvId = db.prepare("SELECT id FROM users WHERE email = 'tv@t.fi'").get().id;
  const mk = await users.admin('POST', '/users', { name: 'Avustaja Kaksi', email: 'tt2@t.fi', role: 'tuntityontekija', project_ids: [p.KATUKLINIKKA] });
  assert.equal(mk.status, 201, JSON.stringify(mk.data));
  const ttId = mk.data.id ?? db.prepare("SELECT id FROM users WHERE email = 'tt2@t.fi'").get().id;
  const htId = db.prepare("SELECT id FROM users WHERE email = 'ht@t.fi'").get().id;
  const form = await tv('GET', '/form');
  const members = form.data.members[p.KATUKLINIKKA].map(m => m.id);
  assert.ok(members.includes(ttId) && !members.includes(tvId), 'lista: hankkeen muut käyttäjät');
  const TT = 'Tuntityöntekijä tai ulkopuolinen asiantuntija, ohjaaja, avustaja tai neuvontapalvelun vastaaja';
  // Tiiminvetäjä kirjaa tuntityöntekijän puolesta: rooli toteuttajasta, kirjaaja säilyy
  let r = await tv('POST', '/encounters', basePayload(p.KATUKLINIKKA, { performer: String(ttId) }));
  assert.equal(r.status, 201, JSON.stringify(r.data));
  let e = db.prepare('SELECT * FROM encounters WHERE id = ?').get(r.data.id);
  assert.equal(e.performed_by, ttId); assert.equal(e.created_by, tvId); assert.equal(e.recorder_role, TT);
  // Työntekijäseuranta laskee kohtaamisen toteuttajalle
  const st = await users.admin('GET', `/staff/${ttId}?from=2020-01-01&to=${today}`);
  assert.ok(st.data.kpi.rows >= 1);
  // Vapaaehtoinen
  r = await tv('POST', '/encounters', basePayload(p.KATUKLINIKKA, { performer: 'vapaaehtoinen' }));
  e = db.prepare('SELECT * FROM encounters WHERE id = ?').get(r.data.id);
  assert.equal(e.performer_type, 'vapaaehtoinen'); assert.equal(e.performed_by, null);
  assert.equal(e.recorder_role, 'Vertainen, kokemusasiantuntija tai vapaaehtoinen');
  // Hankkeeseen kuulumaton käyttäjä ei kelpaa
  const outsider = db.prepare("SELECT id FROM users WHERE is_test = 0 AND role <> 'admin' AND id NOT IN (SELECT user_id FROM user_projects WHERE project_id = ?)").get(p.VOLJY);
  if (outsider) assert.equal((await tv('POST', '/encounters', basePayload(p.VOLJY, { performer: String(outsider.id) }))).status, 400);
  // Hanketyöntekijän puolesta kirjattu näkyy hänelle ja hän voi korjata sen; korjaus säilyttää toteuttajan
  r = await tv('POST', '/encounters', basePayload(p.KATUKLINIKKA, { performer: String(htId) }));
  assert.equal(r.status, 201, JSON.stringify(r.data));
  const own = await users.hanketyontekija('GET', '/encounters');
  assert.ok(own.data.rows.some(x => x.id === r.data.id));
  const upd = await users.hanketyontekija('PUT', '/encounters/' + r.data.id, basePayload(p.KATUKLINIKKA, { performer: String(htId) }));
  assert.equal(upd.status, 200, JSON.stringify(upd.data));
  assert.equal(db.prepare('SELECT created_by FROM encounters WHERE id = ?').get(r.data.id).created_by, tvId);
});

test('tilastot: koosteet, rajaukset, vertailujakso ja oikeudet', async () => {
  const { shiftPeriod } = require('../src/dashboard');
  assert.deepEqual(shiftPeriod('2026-01-01', '2026-01-31'), ['2025-12-01', '2025-12-31']);
  const a = await users.admin('GET', `/dashboard?from=2020-01-01&to=${today}`);
  assert.equal(a.status, 200, JSON.stringify(a.data));
  const all = db.prepare('SELECT COUNT(*) n, SUM(encounter_count) s FROM encounters WHERE deleted_at IS NULL').get();
  assert.equal(a.data.totals.rows, all.n); assert.equal(a.data.totals.encounters, all.s);
  assert.equal(a.data.totals.yksilo + a.data.totals.ryhma, all.s);
  // Täysin anonyymit: yksilö ilman nimimerkkiä + ryhmien kohtaamiset ilman osallistujamäärää
  const anon = db.prepare(`SELECT COALESCE(SUM(CASE WHEN encounter_type = 'yksilo' AND client_id IS NULL THEN encounter_count END), 0)
    + COALESCE(SUM(CASE WHEN encounter_type = 'ryhma' AND person_count IS NULL THEN encounter_count END), 0) n FROM encounters WHERE deleted_at IS NULL`).get().n;
  assert.equal(a.data.totals.anonymous, anon);
  assert.ok(a.data.totals.anon_group > 0, 'testidatassa on ryhmiä ilman osallistujamäärää');
  assert.ok(Math.abs(a.data.totals.anonymous_share - anon / all.s) < 1e-9);
  assert.ok(a.data.monthly.length >= 1 && a.data.byProject.length >= 2);
  assert.ok(a.data.distributions.some(d => d.key === 'ika'));
  // Tyyppirajaus
  // Vertailu vain pyydettäessä
  assert.equal(a.data.previous, null); assert.equal(a.data.monthlyPrev, null);
  const y = await users.admin('GET', `/dashboard?from=2024-02-29&to=2024-12-31&compare=year`);
  assert.equal(y.data.period.prevFrom, '2023-02-28'); assert.equal(y.data.period.prevTo, '2023-12-31');
  assert.ok(y.data.previous && Array.isArray(y.data.monthlyPrev));
  const pr = await users.admin('GET', `/dashboard?from=2026-01-01&to=2026-01-31&compare=prev`);
  assert.equal(pr.data.period.prevFrom, '2025-12-01'); assert.equal(pr.data.period.prevTo, '2025-12-31');
  const g = await users.admin('GET', `/dashboard?from=2020-01-01&to=${today}&types=ryhma`);
  assert.equal(g.data.totals.yksilo, 0);
  // Ikärajaus
  const ik = await users.admin('GET', `/dashboard?from=2020-01-01&to=${today}&ika=${encodeURIComponent('18–29 vuotta')}`);
  assert.ok(ik.data.totals.rows >= 1 && ik.data.totals.rows < all.n);
  // Hanketyöntekijä näkee kaikkien hankkeiden tilastot (koosteet)
  const ht = await users.hanketyontekija('GET', `/dashboard?from=2020-01-01&to=${today}`);
  assert.equal(ht.status, 200);
  assert.equal(ht.data.totals.rows, all.n);
  assert.equal((await users.hanketyontekija('GET', `/dashboard?from=2020-01-01&to=${today}&project_id=${P().JALMA}`)).status, 200);
  assert.equal((await users.tuntityontekija('GET', '/dashboard')).status !== 200, true);
  // Ei tunnisteita tai vapaatekstejä
  assert.ok(!/revontuli|Keskustelu|Hyvä keskustelu/i.test(JSON.stringify(a.data)));
});

test('täydennysehdotukset: kunnat ja aiemmin kirjatut, kadut kaupungin mukaan, yksittäinen toisen arvo ei näy', async () => {
  const p = P(); const tv = users.tiimivetaja;
  let r = await tv('GET', '/suggest?key=kaupunki&q=ta');
  assert.equal(r.status, 200);
  assert.ok(r.data.items.includes('Tampere'), JSON.stringify(r.data));
  assert.equal((await tv('GET', '/suggest?key=kaupunki&q=t')).data.items.length, 0, 'alle 2 merkkiä');
  assert.equal((await tv('GET', '/suggest?key=tyontekijan_huomiot&q=hy')).data.items.length, 0, 'vain sallitut kysymykset');
  // Kadunnimi: kaksi kirjausta Tampereella, yksi Turussa toisen käyttäjän tekemänä
  for (let i = 0; i < 2; i++) await tv('POST', '/encounters', basePayload(p.KATUKLINIKKA, { answers: { tyontekijan_arvio: '4', sijainti: 'Kadulla tai muulla julkisella paikalla', kaupunki: 'Tampere', kadunnimi: 'Hämeenkatu' } }));
  await users.admin('POST', '/encounters', basePayload(p.KATUKLINIKKA, { answers: { tyontekijan_arvio: '4', sijainti: 'Kadulla tai muulla julkisella paikalla', kaupunki: 'Turku', kadunnimi: 'Kummitusraitti 5 rappu' } }));
  r = await tv('GET', '/suggest?key=kadunnimi&q=häm&kaupunki=tampere');
  assert.equal(r.data.items[0], 'Hämeenkatu', 'eniten käytetty ensin');
  r = await tv('GET', '/suggest?key=kadunnimi&q=kummitus');
  assert.ok(!r.data.items.includes('Kummitusraitti'), 'toisen yksittäinen arvo ei näy');
  assert.ok((await users.admin('GET', '/suggest?key=kadunnimi&q=kummitus')).data.items.includes('Kummitusraitti'), 'oma arvo näkyy');
  // Hankerajaus: hanketyöntekijä (vain Katuklinikka) näkee Katuklinikan kirjaukset
  assert.ok((await users.hanketyontekija('GET', '/suggest?key=kadunnimi&q=häm')).data.items.includes('Hämeenkatu'));
});

test('kadunnimet: kunnan kadut omasta aineistosta, kaupungin mukaan', async () => {
  let r = await users.tiimivetaja('GET', '/suggest?key=kadunnimi&q=kirkkok&kaupunki=oulu');
  assert.ok(r.data.items.includes('Kirkkokatu'), JSON.stringify(r.data));
  r = await users.tiimivetaja('GET', '/suggest?key=kadunnimi&q=mannerheimin&kaupunki=Helsinki');
  assert.ok(r.data.items.includes('Mannerheimintie'));
  r = await users.tiimivetaja('GET', '/suggest?key=kadunnimi&q=stor&kaupunki=Mariehamn');
  assert.ok(r.data.items.length > 0, 'ruotsinkielinen kuntanimi');
  r = await users.tiimivetaja('GET', '/suggest?key=kadunnimi&q=mannerheimin&kaupunki=Atlantis');
  assert.ok(!r.data.items.includes('Mannerheimintie'), 'tuntematon kunta ei tuo katuja');
  assert.equal(require('../src/kunnat.json').length, 308);
});

test('nimimerkki: ääkköset ja kirjainkoko eivät estä löytymistä; vanha tiiviste päivittyy', async () => {
  const p = P(); const tv = users.tiimivetaja; const clients = require('../src/clients');
  let r = await tv('POST', '/encounters', basePayload(p.KATUKLINIKKA, { client_mode: 'new', client_ref: 'Tähtinen Mäyrä', client_generated: true }));
  assert.equal(r.status, 201, JSON.stringify(r.data));
  for (const v of ['tähtinen mäyrä', 'Tahtinen Mayra', 'TAHTINEN-MAYRA']) {
    r = await tv('POST', '/clients/lookup', { ref: v, project_id: p.KATUKLINIKKA });
    assert.equal(r.data.found, true, v);
  }
  // Vanha (ääkkösiä erotteleva) tiiviste löytyy alkuperäisellä kirjoitusasulla ja päivittyy
  const crypto = require('crypto');
  const v1 = crypto.createHmac('sha256', 'kehitys-avain-ei-tuotantoon').update(`asiakas:p${p.KATUKLINIKKA}:` + clients.normalize('Pöllö Ilves')).digest('hex');
  db.prepare('INSERT INTO clients (project_id, ref_hash, legacy) VALUES (?, ?, 0)').run(p.KATUKLINIKKA, v1);
  assert.ok(clients.findClient(p.KATUKLINIKKA, 'pöllö ilves'));
  assert.ok(clients.findClient(p.KATUKLINIKKA, 'pollo ilves'), 'päivityksen jälkeen myös ilman ääkkösiä');
});

test('tilastot: paikkakunnat ja kadut, kirjoitusasut yhdistetään, paikkakuntarajaus', async () => {
  const p = P(); const tv = users.tiimivetaja;
  const ans = (kaupunki, kadunnimi) => ({ tyontekijan_arvio: '4', sijainti: 'Kadulla tai muulla julkisella paikalla', kaupunki, kadunnimi });
  await tv('POST', '/encounters', basePayload(p.KATUKLINIKKA, { encounter_date: '2021-03-01', answers: ans('Lahti', 'Aleksanterinkatu') }));
  await tv('POST', '/encounters', basePayload(p.KATUKLINIKKA, { encounter_date: '2021-03-02', answers: ans('lahti ', 'aleksanterinkatu') }));
  await tv('POST', '/encounters', basePayload(p.KATUKLINIKKA, { encounter_date: '2021-03-03', answers: ans('Lahti', 'Vesijärvenkatu') }));
  await tv('POST', '/encounters', basePayload(p.KATUKLINIKKA, { encounter_date: '2021-03-04', answers: ans('Kotka', 'Keskuskatu') }));
  const d = await users.admin('GET', '/dashboard?from=2021-03-01&to=2021-03-31');
  const lahti = d.data.places.cities.find(c => c.label === 'Lahti');
  assert.equal(lahti.encounters, 3, JSON.stringify(d.data.places));
  const alek = d.data.places.streets.find(s => s.label === 'Aleksanterinkatu');
  assert.equal(alek.encounters, 2); assert.equal(alek.city, 'Lahti');
  const f = await users.admin('GET', '/dashboard?from=2021-03-01&to=2021-03-31&kaupunki=LAHTI');
  assert.equal(f.data.totals.encounters, 3);
  assert.ok(!f.data.places.streets.some(s => s.label === 'Keskuskatu'));
  assert.ok(f.data.places.cities.length >= 2, 'paikkakuntalista ei rajaudu itseensä');
});

test('kirjaustyypit: tavoittaminen tilastoidaan erikseen, admin lisää tyypin', async () => {
  const p = P(); const tv = users.tiimivetaja;
  const types = (await tv('GET', '/me')).data.recordTypes.map(t => t.key);
  assert.deepEqual(types, ['yksilo', 'ryhma', 'tavoittaminen']);
  // Tavoittamisen muoto pakollinen, tavoitettujen määrä pakollinen
  let r = await tv('POST', '/encounters', { project_id: p.JALMA ?? p.KATUKLINIKKA, encounter_date: '2022-05-05', encounter_type: 'tavoittaminen', answers: {} });
  assert.equal(r.status, 400);
  r = await tv('POST', '/encounters', { project_id: p.KATUKLINIKKA, encounter_date: '2022-05-05', encounter_type: 'tavoittaminen', encounter_count: 40,
    answers: { tavoittamisen_muoto: 'Luento', tyontekijan_arvio: '4', ika: '18–29 vuotta' } });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  const e = db.prepare('SELECT * FROM encounters WHERE id = ?').get(r.data.id);
  assert.equal(e.kind, 'tavoittaminen'); assert.equal(e.person_count, null);
  const d = await users.admin('GET', '/dashboard?from=2022-05-01&to=2022-05-31');
  assert.equal(d.data.totals.reach, 40); assert.equal(d.data.totals.encounters, 0, 'tavoitetut eivät ole kohtaamisia');
  // Ikä ei koske tavoittamista
  assert.equal((await tv('GET', '/encounters/' + r.data.id)).data.encounter.answers.ika, undefined);
  // Admin lisää tyypin, tiiminvetäjä ei
  assert.equal((await tv('POST', '/record-types', { label: 'Puhelinneuvonta', kind: 'yksilo' })).status, 403);
  const n = await users.admin('POST', '/record-types', { label: 'Puhelinneuvonta', description: 'Yksi puhelu', kind: 'yksilo' });
  assert.equal(n.status, 201); assert.equal(n.data.key, 'puhelinneuvonta');
  r = await tv('POST', '/encounters', basePayload(p.KATUKLINIKKA, { encounter_type: 'puhelinneuvonta' }));
  assert.equal(r.status, 201, JSON.stringify(r.data));
  assert.equal(db.prepare('SELECT kind FROM encounters WHERE id = ?').get(r.data.id).kind, 'yksilo');
  // Pois käytöstä: uusia kirjauksia ei voi tehdä
  await users.admin('PUT', '/record-types/puhelinneuvonta', { label: 'Puhelinneuvonta', active: false });
  assert.equal((await tv('POST', '/encounters', basePayload(p.KATUKLINIKKA, { encounter_type: 'puhelinneuvonta' }))).status, 400);
});

test('ehdolliset kysymykset: näkyvät ja vaaditaan vain ehdon täyttyessä; lukujen alaraja', async () => {
  const p = P(); const tv = users.tiimivetaja;
  db.prepare("UPDATE questions SET required = 1 WHERE key IN ('voljy_asumistuki','voljy_asuminen_toimenpiteet','voljy_asuminen_tulos')").run();
  db.prepare('INSERT OR IGNORE INTO user_projects (user_id, project_id) SELECT id, ? FROM users WHERE email = ?').run(p.VOLJY, 'tv@t.fi');
  const base = (answers) => ({ project_id: p.VOLJY, encounter_date: today, encounter_type: 'yksilo', answers: { tyontekijan_arvio: '4', ...answers } });
  // Ei asumistukea → jatkokysymyksiä ei vaadita eikä tallenneta
  let r = await tv('POST', '/encounters', base({ voljy_asumistuki: 'Ei', voljy_asuminen_toimenpiteet: '3' }));
  assert.equal(r.status, 201, JSON.stringify(r.data));
  assert.equal((await tv('GET', '/encounters/' + r.data.id)).data.encounter.answers.voljy_asuminen_toimenpiteet, undefined);
  // Asumistuki annettu → jatkokysymykset pakollisia
  r = await tv('POST', '/encounters', base({ voljy_asumistuki: 'Kyllä' }));
  assert.equal(r.status, 400);
  r = await tv('POST', '/encounters', base({ voljy_asumistuki: 'Kyllä', voljy_asuminen_toimenpiteet: '-1', voljy_asuminen_tulos: ['Häätö ehkäistiin'] }));
  assert.equal(r.status, 400, 'negatiivinen luku hylätään');
  r = await tv('POST', '/encounters', base({ voljy_asumistuki: 'Kyllä', voljy_asuminen_toimenpiteet: '2', voljy_asuminen_tulos: ['Häätö ehkäistiin'] }));
  assert.equal(r.status, 201, JSON.stringify(r.data));
  // Toteuttajan rooliin sidottu ehto (Päihdelinkki: vain ammattilaiset)
  const q = db.prepare("SELECT show_if FROM questions WHERE key = 'ak21_selkiytyminen'").get();
  assert.ok(JSON.parse(q.show_if).key === '_toteuttaja');
  db.prepare("UPDATE questions SET required = 1 WHERE key = 'ak21_selkiytyminen'").run();
  r = await tv('POST', '/encounters', basePayload(p.AK21, { performer: 'vapaaehtoinen' }));
  assert.equal(r.status, 201, 'vapaaehtoiselta ei kysytä ' + JSON.stringify(r.data));
  r = await tv('POST', '/encounters', basePayload(p.AK21));
  assert.equal(r.status, 400, 'ammattilaiselta kysytään');
  db.prepare("UPDATE questions SET required = 0 WHERE key = 'ak21_selkiytyminen'").run();
  // Admin voi asettaa ehdon ja tyypit kysymykselle
  const nq = await users.admin('POST', '/questions', { key: 'testi_ehto', label: 'Testiehto', type: 'text', project_id: p.VOLJY, applies: ['yksilo'],
    show_if: { key: 'voljy_asumistuki', values: ['Kyllä'] } });
  assert.equal(nq.status, 201, JSON.stringify(nq.data));
  const bad = await users.admin('POST', '/questions', { key: 'testi_ehto2', label: 'Testi', type: 'text', show_if: { key: 'voljy_asumistuki', values: ['Kyllä'] } });
  assert.equal(bad.status, 400, 'yhteinen kysymys ei voi riippua hankekohtaisesta');
});

test('roolit: uusi lukurooli, oikeuksien tarkistus ja suojaukset', async () => {
  const a = users.admin;
  const list = await a('GET', '/roles');
  assert.equal(list.status, 200);
  assert.ok(['admin', 'tiimivetaja', 'hanketyontekija', 'tuntityontekija'].every(k => list.data.roles.some(r => r.key === k)));
  assert.equal((await users.tiimivetaja('GET', '/roles')).status, 403);

  // Lukija: vain tilastot ja työntekijäseuranta
  const r = await a('POST', '/roles', { label: 'Tilastojen lukija', description: 'Vain luku', recorder_index: 0, foundation: false,
    permissions: { dashScope: 'all', staffScope: 'all', editScope: 'all', manageUsers: 'kyllä', bogus: true } });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  const key = r.data.key;
  const saved = (await a('GET', '/roles')).data.roles.find(x => x.key === key);
  assert.equal(saved.permissions.editScope, 'none', 'korjaus ei voi olla laajempi kuin selaus');
  assert.equal(saved.permissions.manageUsers, false);
  assert.equal(saved.permissions.bogus, undefined);
  assert.equal((await a('POST', '/roles', { label: 'tilastojen LUKIJA', recorder_index: 0 })).status, 400);

  const u = await a('POST', '/users', { name: 'Lukija', email: 'lukija@t.fi', role: key, project_ids: [] });
  assert.equal(u.status, 201);
  let c = await login('lukija@t.fi', u.data.temporaryPassword);
  await c('POST', '/me/password', { current: u.data.temporaryPassword, next: 'Uusi-salasana-123' });
  c = await login('lukija@t.fi', 'Uusi-salasana-123');
  const me = await c('GET', '/me');
  assert.equal(me.data.user.roleLabel, 'Tilastojen lukija');
  assert.equal(me.data.permissions.record, false);
  assert.equal((await c('GET', '/dashboard')).status, 200);
  assert.equal((await c('GET', '/staff')).status, 200);
  assert.equal((await c('GET', '/encounters')).status, 403);
  assert.equal((await c('POST', '/encounters', basePayload(P().JALMA))).status, 403);
  assert.equal((await c('GET', '/export?from=2026-01-01&to=2026-12-31')).status, 403);
  assert.equal((await c('GET', '/users')).status, 403);

  // Oikeuksien muutos tulee voimaan heti
  assert.equal((await a('PUT', '/roles/' + key, { label: 'Tilastojen lukija', recorder_index: 0, permissions: { dashScope: 'all' } })).status, 200);
  assert.equal((await c('GET', '/staff')).status, 403);

  // Suojaukset
  assert.equal((await a('PUT', '/roles/admin', { label: 'Admin', recorder_index: 0, permissions: {} })).status, 400);
  assert.equal((await a('PUT', '/roles/' + key, { label: 'Tilastojen lukija', recorder_index: 0, active: false, permissions: { dashScope: 'all' } })).status, 400, 'roolissa käyttäjiä');
  assert.equal((await a('DELETE', '/roles/' + key)).status, 400);
  assert.equal((await a('DELETE', '/roles/tuntityontekija')).status, 400);
  assert.equal((await a('POST', '/users', { name: 'X', email: 'x@t.fi', role: 'olematon', project_ids: [] })).status, 400);
  const tmp = await a('POST', '/roles', { label: 'Poistettava', recorder_index: 1 });
  assert.equal((await a('DELETE', '/roles/' + tmp.data.key)).status, 200);
});

test('kohtaamisen päivä ei voi olla tulevaisuudessa (Suomen aika)', async () => {
  const fi = new Intl.DateTimeFormat('sv-SE', { timeZone: 'Europe/Helsinki' }).format(new Date());
  const d = new Date(fi + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + 1);
  const r = await users.admin('POST', '/encounters', basePayload(P().JALMA, { encounter_date: d.toISOString().slice(0, 10) }));
  assert.equal(r.status, 400); assert.match(r.data.error, /tulevaisuudessa/);
  assert.equal((await users.admin('GET', '/me')).data.today, fi);
  assert.equal((await users.admin('POST', '/encounters', basePayload(P().JALMA, { encounter_date: fi }))).status, 201);
});

test('uudelleenlähetys samalla tunnisteella ei luo kaksoiskirjausta', async () => {
  const rid = require('crypto').randomUUID();
  const before = db.prepare('SELECT COUNT(*) n FROM encounters').get().n;
  const a = await users.admin('POST', '/encounters', basePayload(P().JALMA, { client_request_id: rid }));
  const b = await users.admin('POST', '/encounters', basePayload(P().JALMA, { client_request_id: rid }));
  assert.equal(a.status, 201); assert.equal(b.status, 201);
  assert.equal(a.data.id, rid); assert.equal(b.data.id, rid); assert.equal(b.data.duplicate, true);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM encounters').get().n, before + 1);
  // Toisen käyttäjän tunniste ei palauta toisen kirjausta
  const c = await users.tiimivetaja('POST', '/encounters', basePayload(P().KATUKLINIKKA, { client_request_id: rid }));
  assert.equal(c.status, 201); assert.notEqual(c.data.id, rid);
});

test('kadunnimestä tallentuu vain kadun nimi', async () => {
  const r = await users.admin('POST', '/encounters', basePayload(P().JALMA, { answers: { tyontekijan_arvio: '4', sijainti: 'Kadulla tai muulla julkisella paikalla', kaupunki: 'Helsinki', kadunnimi: 'Mannerheimintie 12 A 5' } }));
  assert.equal(r.status, 201, JSON.stringify(r.data));
  const v = db.prepare(`SELECT a.value FROM encounter_answers a JOIN questions q ON q.id = a.question_id WHERE q.key = 'kadunnimi' AND a.encounter_id = ?`).get(r.data.id);
  assert.equal(v.value, 'Mannerheimintie');
  const { streetOnly } = require('../src/streets');
  assert.equal(streetOnly('Kauppakatu 3, Tampere'), 'Kauppakatu');
  assert.equal(streetOnly('2. linja 5'), '2. linja');
  assert.equal(streetOnly('Aleksis Kiven katu 3 C 22'), 'Aleksis Kiven katu');
});

test('muut toteuttajat: vapaaehtoinen ja vertainen erikseen, ylläpidettävät', async () => {
  const p = P(); const tv = users.tiimivetaja;
  const me = await tv('GET', '/me');
  assert.deepEqual(me.data.performerTypes.filter(t => t.active).map(t => t.label), ['Vapaaehtoinen', 'Vertainen']);
  const r = await tv('POST', '/encounters', basePayload(p.KATUKLINIKKA, { performer: 'vertainen' }));
  assert.equal(r.status, 201, JSON.stringify(r.data));
  const e = db.prepare('SELECT * FROM encounters WHERE id = ?').get(r.data.id);
  assert.equal(e.performer_type, 'vertainen'); assert.equal(e.performed_by, null);
  assert.equal(e.recorder_role, 'Vertainen, kokemusasiantuntija tai vapaaehtoinen');
  // Admin lisää toteuttajan ja valitsee sille roolin
  assert.equal((await tv('POST', '/performer-types', { label: 'X', recorder_index: 2 })).status, 403);
  const add = await users.admin('POST', '/performer-types', { label: 'Kokemusasiantuntija', recorder_index: 1 });
  assert.equal(add.status, 201);
  const r2 = await tv('POST', '/encounters', basePayload(p.KATUKLINIKKA, { performer: add.data.key }));
  assert.equal(db.prepare('SELECT recorder_role FROM encounters WHERE id = ?').get(r2.data.id).recorder_role, 'Tuntityöntekijä tai ulkopuolinen asiantuntija, ohjaaja, avustaja tai neuvontapalvelun vastaaja');
  // Käytöstä poistettu ei kelpaa uusiin kirjauksiin
  assert.equal((await users.admin('PUT', '/performer-types/' + add.data.key, { label: 'Kokemusasiantuntija', recorder_index: 1, active: false })).status, 200);
  assert.equal((await tv('POST', '/encounters', basePayload(p.KATUKLINIKKA, { performer: add.data.key }))).status, 400);
  const list = await users.admin('GET', '/performer-types');
  assert.ok(list.data.types.find(t => t.key === 'vertainen').encounter_rows >= 1);
});
